package view;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.ClientTasks;
import model.Customer;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EtchedBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class CustomerDashboardGUI extends JFrame {
	
	private JPanel contentPane;
	private final JPanel panel = new JPanel();
	private Customer customer;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				
					//CustomerDashboardGUI frame = new CustomerDashboardGUI(frame);
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerDashboardGUI(JFrame mainFrame, Customer customer) {
		setTitle("Grizzly Dashboard");
		
		// Store the customer object
		ClientTasks task= new ClientTasks();
        this.customer = customer;
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 916, 525);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(56, 141, 146));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		panel.setBackground(new Color(168, 247, 198));
		panel.setBounds(0, 0, 271, 488);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel bannerPanel = new JPanel();
		bannerPanel.setBackground(new Color(154, 248, 222));
		bannerPanel.setBounds(0, 11, 903, 57);
		panel.add(bannerPanel);
		bannerPanel.setLayout(null);
		
		System.out.print(customer);
		JLabel welcomelbl = new JLabel("WELCOME!!" + customer.getFirstName());
		welcomelbl.setFont(new Font("Lucida Calligraphy", Font.BOLD, 18));
		welcomelbl.setBounds(23, 21, 236, 25);
		bannerPanel.add(welcomelbl);
		
		JLabel lblNewLabel = new JLabel("Customer Dashboard");
		lblNewLabel.setFont(new Font("Lucida Calligraphy", Font.PLAIN, 20));
		lblNewLabel.setBounds(28, 195, 233, 74);
		panel.add(lblNewLabel);
		
		JButton logoutButton = new JButton("LOGOUT");
		logoutButton.setBackground(new Color(176, 228, 236));
		logoutButton.setFont(new Font("Georgia", Font.PLAIN, 12));
		logoutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainWindow main= new MainWindow();
				main.setVisible(true);
				setVisible(false);
			}
		});
		logoutButton.setBounds(97, 376, 89, 23);
		panel.add(logoutButton);
		
		
		JPanel viewPanel = new JPanel();
		viewPanel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		viewPanel.addMouseListener(new MouseAdapter() {
			@Override
			//Action Listener that shows the view products gui on the dashboard
			public void mouseClicked(MouseEvent e) {
				ViewEquipmentGUI viewEquipment= new ViewEquipmentGUI(CustomerDashboardGUI.this);
				viewEquipment.setVisible(true);
			}
		});
		viewPanel.setBounds(336, 76, 207, 150);
		contentPane.add(viewPanel);
		viewPanel.setLayout(null);
		
		JLabel viewProductsLbl = new JLabel("View Products");
		viewProductsLbl.setFont(new Font("Lucida Calligraphy", Font.BOLD, 19));
		viewProductsLbl.setBounds(23, 63, 160, 41);
		viewPanel.add(viewProductsLbl);
		
		
		JPanel transactionPanel = new JPanel();
		transactionPanel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		transactionPanel.addMouseListener(new MouseAdapter() {
			@Override
			//Action Listener that shows the view transactions gui on the dashboard
			public void mouseClicked(MouseEvent e) {
				ViewTransactionsGUI transactionsGUI= new ViewTransactionsGUI(task, customer);
				
				transactionsGUI.setVisible(true);
			}
		});
		transactionPanel.setBounds(649, 76, 207, 150);
		contentPane.add(transactionPanel);
		transactionPanel.setLayout(null);
		
		JLabel transactionsLbl = new JLabel("My Transactions");
		transactionsLbl.setFont(new Font("Lucida Calligraphy", Font.BOLD, 19));
		transactionsLbl.setBounds(10, 67, 187, 25);
		transactionPanel.add(transactionsLbl);
		
		JPanel settingsPanel = new JPanel();
		settingsPanel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		
		settingsPanel.setBounds(336, 288, 204, 150);
		contentPane.add(settingsPanel);
		settingsPanel.setLayout(null);
		
		JLabel settingsLbl = new JLabel("Account Settings");
		settingsLbl.addMouseListener(new MouseAdapter() {
			@Override
			//Action Listener that shows the account settings gui on the dashboard
			public void mouseClicked(MouseEvent e) {
				AccountSettingsGUI settings=new AccountSettingsGUI(customer);
				settings.setVisible(true);
			}
		});
		settingsLbl.setFont(new Font("Lucida Calligraphy", Font.BOLD, 19));
		settingsLbl.setBounds(10, 24, 184, 115);
		settingsPanel.add(settingsLbl);
		
		JPanel messagePanel = new JPanel();
		messagePanel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		//Action Listener that shows the messages gui on the dashboard
		 messagePanel.addMouseListener(new MouseAdapter() {
		      @Override
		      public void mouseClicked(MouseEvent e) {
		        SendMessageGUI message = new SendMessageGUI(CustomerDashboardGUI.this, customer);
		        message.setVisible(true);
		      }
		    });
		messagePanel.setBounds(649, 288, 207, 150);
		contentPane.add(messagePanel);
		messagePanel.setLayout(null);
		
		JLabel messageLbl = new JLabel("Messages");
		messageLbl.setBounds(50, 65, 105, 23);
		messageLbl.setFont(new Font("Lucida Calligraphy", Font.BOLD, 19));
		messagePanel.add(messageLbl);
		
	}
}
