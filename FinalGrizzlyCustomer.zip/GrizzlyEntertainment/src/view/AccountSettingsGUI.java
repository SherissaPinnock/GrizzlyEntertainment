package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import controller.ClientTasks;
import model.Customer;
import model.Message;

import java.awt.Font;
import java.awt.Color;

public class AccountSettingsGUI extends JFrame {

	private JPanel contentPane;
	private JPanel changeInfoPanel;
	private JPanel deleteAccountPanel;
	private JTextField passwordField;
	private JTextField emailField;
	private JTextField phoneField;
	Customer customer;
	
	 //used for logging to file and console
	private static final Logger logger= LogManager.getLogger(AccountSettingsGUI.class);

	/**
	 * Create the frame.
	 */
	public AccountSettingsGUI(Customer customer) {
		ClientTasks task= new ClientTasks();
		this.customer = customer;
		setTitle("Account Settings");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 409, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(69, 188, 180));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		// Create panels for each option
        changeInfoPanel = new JPanel();
        changeInfoPanel.add(new JLabel("Change Info Panel"));

        deleteAccountPanel = new JPanel();
        deleteAccountPanel.add(new JLabel("Delete Account Panel"));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 395, 22);
		contentPane.add(menuBar);

	     // Create a menu
	     JMenu accountMenu = new JMenu("Account");

	     // Create menu items
	     JMenuItem changeInfoItem = new JMenuItem("Change Info");
	     JMenuItem deleteAccountItem = new JMenuItem("Delete Account");
	     
	     // Add menu items to the menu
	        accountMenu.add(changeInfoItem);
	        accountMenu.add(deleteAccountItem);

	        // Add the menu to the menu bar
	        menuBar.add(accountMenu);
	        
	        JLabel lblNewLabel = new JLabel("Change Password");
	        lblNewLabel.setFont(new Font("Georgia", Font.PLAIN, 13));
	        lblNewLabel.setBounds(21, 50, 111, 22);
	        contentPane.add(lblNewLabel);
	        
	        passwordField = new JTextField();
	        passwordField.setBounds(142, 52, 123, 20);
	        contentPane.add(passwordField);
	        passwordField.setColumns(10);
	        
	        JLabel lblNewLabel_1 = new JLabel("Change Email");
	        lblNewLabel_1.setFont(new Font("Georgia", Font.PLAIN, 13));
	        lblNewLabel_1.setBounds(21, 95, 111, 20);
	        contentPane.add(lblNewLabel_1);
	        
	        emailField = new JTextField();
	        emailField.setBounds(142, 96, 123, 20);
	        contentPane.add(emailField);
	        emailField.setColumns(10);
	        
	        JLabel lblNewLabel_4 = new JLabel("Change Phone");
	        lblNewLabel_4.setFont(new Font("Georgia", Font.PLAIN, 13));
	        lblNewLabel_4.setBounds(21, 143, 96, 18);
	        contentPane.add(lblNewLabel_4);
	        
	        phoneField = new JTextField();
	        phoneField.setBounds(142, 143, 123, 20);
	        contentPane.add(phoneField);
	        phoneField.setColumns(10);
	       
	        //this action listener will request to the server that the client wants to delete their account
	        //and it will send back a response from the server to the client
	        deleteAccountItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	            	setContentPane(deleteAccountPanel);
	                revalidate();
	                repaint();
	               
	                int choice = JOptionPane.showConfirmDialog(AccountSettingsGUI.this, "Are you sure you want to delete your account?",
	                        "Confirm Deletion", JOptionPane.YES_NO_OPTION);
	                if (choice == JOptionPane.YES_OPTION) {
	                    JOptionPane.showMessageDialog(AccountSettingsGUI.this, "Account deleted successfully");
	                    task.sendAction("Delete Account");
	                    task.sendCustomerId(customer.getCustomerID());
	                    logger.info("Sent "+ customer.getCustomerID());
	                    task.receiveResponse();
	                    MainWindow main= new MainWindow();
	    				main.setVisible(true);
	    				setVisible(false);
	                }
	            }
	        });
		       
	        //this action listener will request to the server that the client wants to update their account
	        //and it will send back a response from the server to the client
		    changeInfoItem.addActionListener(new ActionListener() {
		       @Override
		       public void actionPerformed(ActionEvent e) {
		        	
		    	   	String password = passwordField.getText();
		 	        String email = emailField.getText();
		 	        String phone = phoneField.getText();
		 	     
		 	        task.sendAction("Update Account");
		 	        task.sendCustomerPassword(password); 
		 	        task.sendCustomerEmail(email); 
		 	        task.sendCustomerPhone(phone); 
		 	        task.sendCustomerId(customer.getCustomerID());
		         	task.receiveResponse();
		        }
		        
		      });
	}
}
