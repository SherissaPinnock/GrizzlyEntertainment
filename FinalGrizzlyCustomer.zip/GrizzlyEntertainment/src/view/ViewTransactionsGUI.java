package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.ClientTasks;
import model.Customer;
import model.Transaction;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ViewTransactionsGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private ClientTasks task;
	private Customer customer;


	/**
	 * Create the frame.
	 */
	public ViewTransactionsGUI(ClientTasks task, Customer customer) {
		setTitle("My Transactions");
		this.task=task;
		this.customer=customer; 
		 setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
		setBounds(100, 100, 713, 422);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(115, 215, 205));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel headingLabel = new JLabel("My Transactions");
		headingLabel.setFont(new Font("Lucida Calligraphy", Font.BOLD, 18));
		headingLabel.setBounds(21, 23, 173, 30);
		contentPane.add(headingLabel);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(223, 62, 407, 270);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setBackground(new Color(255, 255, 221));
		scrollPane.setViewportView(table);
		
		
		JButton viewAllButton = new JButton("View All");
		viewAllButton.setBackground(new Color(62, 188, 230));
		
		//Action Listener for View All Button
		viewAllButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				task.sendAction("View All Transactions");
				task.sendCustomerId(customer.getCustomerID());
				task.receiveResponse();
				// Populate the JTable with received data
	            List<Transaction> receivedTransactions = task.getReceivedTransactions();
	            populateTransactionsTable(receivedTransactions);
				
			}
		});
		viewAllButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		viewAllButton.setBounds(44, 121, 108, 42);
		contentPane.add(viewAllButton);
		
		JComboBox transComboBox = new JComboBox();
		transComboBox.setBounds(44, 234, 108, 30);
		contentPane.add(transComboBox);
		task.fillTransComboBox(customer.getCustomerID(), transComboBox); //Populates the ComboBox with the rental IDs
		
		
		// Add an action listener to the JComboBox to load transaction details when an item is selected
		transComboBox.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	ClientTasks task=new ClientTasks();
		        // Get the selected rental ID
		        String selectedRentalID = transComboBox.getSelectedItem().toString();
		        int rentalID = Integer.parseInt(selectedRentalID);
		        task.sendAction("View Single Transaction");
				//task.sendCustomerId(customer.getCustomerID());
				task.sendCustomerId(rentalID);
				task.receiveResponse();
		        // Call the method to retrieve single transaction
		        List<Transaction> singleTransaction = task.getSingleTransaction();
		        populateTransactionsTable(singleTransaction);
		    }
		});

		
		JLabel viewSingleLabel = new JLabel("View Single");
		viewSingleLabel.setFont(new Font("Gadugi", Font.BOLD, 14));
		viewSingleLabel.setBounds(61, 193, 82, 30);
		contentPane.add(viewSingleLabel);
		
		// Create an action for exiting the frame
        Action exitAction = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the frame
            }
        };

        // Add the Ctrl+X shortcut key binding for exiting the frame
        contentPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
                KeyStroke.getKeyStroke(KeyEvent.VK_X, KeyEvent.CTRL_DOWN_MASK), "exitAction");
        contentPane.getActionMap().put("exitAction", exitAction);
    
    }
	
	
	// Create a method to populate the JTable
    public void populateTransactionsTable(List<Transaction> transactions) {
        DefaultTableModel model = new DefaultTableModel();
        table.setModel(model);

        // Add column names to the model
        model.addColumn("Rental ID");
        model.addColumn("Start Date");
        model.addColumn("End Date");
        model.addColumn("Equipment ID");
        model.addColumn("Amount Paid");

        // Populate the model with data
        for (Transaction transaction : transactions) {
            Object[] rowData = { transaction.getRentalID(), transaction.getStartDate(), transaction.getEndDate(), transaction.getEquipmentID(), transaction.getAmountPaid() };
            model.addRow(rowData);
        }
    }
	
	public void updateTransactionsTable(DefaultTableModel model) {
        table.setModel(model); // Update the table in the view
    }
	
	
	
}
