package model;

import java.io.Serializable;

public class Customer implements Serializable{
	/**
	 * 
	 */
	
	private String customerPassword;
	private int customerID;
	private String firstName;
	private String lastName;
	private String email;
	private String phone;
	private double accountBalance;
	private String streetName;
	private String parish;
	
	
	
	public Customer(int customerID, String firstName, String lastName, String customerPassword, 
			String email, String phone, double accountBalance, String streetName, String parish) {
	
		this.customerPassword = customerPassword;
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.accountBalance = accountBalance;
		//this.address=address;
		this.streetName=streetName;
		this.parish=parish;
	}
	
	public Customer() {
		this.customerPassword = "";
		this.customerID = 0;
		this.firstName = "";
		this.lastName = "";
		this.email = "";
		this.phone = "";
		this.accountBalance = 0.0;
		//this.address=new Address("","");
		this.streetName="";
		this.parish="";
	}
	
	/*public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}*/

	public String getCustomerpassword() {
		return customerPassword;
	}
	public void setCustomerpassword(String customerpassword) {
		customerPassword = customerpassword;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getParish() {
		return parish;
	}

	public void setParish(String parish) {
		this.parish = parish;
	}

	@Override
	public String toString() {
		return "Customerpassword=" + customerPassword
				+ ", customerID=" + customerID + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + ", phone=" + phone + ", accountBalance=" + accountBalance + "]";
	}
	
	public boolean validateLogin(String password) {
	    return this.customerPassword.equals(password);
	}

	
}
