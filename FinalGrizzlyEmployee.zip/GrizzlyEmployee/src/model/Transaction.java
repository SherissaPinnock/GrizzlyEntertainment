package model;

import java.io.Serializable;
import java.sql.Date;

public class Transaction implements Serializable{
	private int rentalID;
	private Date startDate;
	private Date endDate;
	private int equipmentID;
	private double amountPaid;
	
	
	
	public Transaction(int rentalID, Date startDate, Date endDate, int equipmentID, double amountPaid) {
		this.rentalID=rentalID;
		this.startDate=startDate;
		this.endDate=endDate;
		this.equipmentID=equipmentID;
		this.amountPaid=amountPaid;
		
	}

	public int getRentalID() {
		return rentalID;
	}


	public void setRentalID(int rentalID) {
		this.rentalID = rentalID;
	}


	public Date getStartDate() {
		return startDate;
	}



	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}



	public Date getEndDate() {
		return endDate;
	}



	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}



	public int getEquipmentID() {
		return equipmentID;
	}



	public void setEquipmentID(int equipmentID) {
		this.equipmentID = equipmentID;
	}



	public double getAmountPaid() {
		return amountPaid;
	}



	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}



	public String toString() {
		return "Transaction [rentalID=" + rentalID + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", equipmentID=" + equipmentID + ", amountPaid=" + amountPaid + "]";
	}

	
}
