package com.grizzly.employeemanagementsystemgui;

import java.util.List; 

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controller.EmployeeTasks;

import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;

import model.Equipment;
import model.Transaction;

public class ViewInventoryGUI {
	
	private static JTable table; 
    private static List<Equipment> inventory;
    
    public static void showViewInventoryGUI() {
  
    	
        JFrame frame = new JFrame("Equipment Inventory");
        frame.setSize(400, 300);

        // Create a label for the heading
        JLabel headingLabel = new JLabel("GrizzlyEntertainment", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Create a DefaultTableModel to hold data for the JTable
        DefaultTableModel model = new DefaultTableModel();

        // Define the column names
        String[] columnNames = {"Equipment ID", "Equipment Name", "Rental Status"};

        // Set the column names in the model
        model.setColumnIdentifiers(columnNames);

        // Create a JTable with the DefaultTableModel
        table = new JTable();

        // Create a JScrollPane to hold the table
        JScrollPane scrollPane = new JScrollPane(table);

        // Create a JPanel to hold the label and table
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(headingLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Add the JPanel to the frame
        frame.add(panel);

        // Set frame properties
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setVisible(true);

        
        //The steps below will allow for the employee to request and receive from the server
        EmployeeTasks empTask= new EmployeeTasks(); 
        empTask.sendAction("View Inventory");
        empTask.receiveResponse();
        inventory= empTask.getInventoryList(); 
        populateTransactionsTable(inventory);
        
    }
    
    public JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 30);
        return button;
    }
    
    public void viewInventory() {
    	showViewInventoryGUI();
    }

    public static void populateTransactionsTable(List<Equipment> equipments) {
        DefaultTableModel model = new DefaultTableModel();
        table.setModel(model);

        // Add column names to the model
        model.addColumn("equipmentID");
        model.addColumn("equipmentName");
        model.addColumn("equipmentCategory");
        model.addColumn("equipmentCostPerDay");
        model.addColumn("equipmentDescription");
        model.addColumn("RentalStatus");

        // Populate the model with data
        for (Equipment equip : equipments) {
            Object[] rowData = {equip.getEquipmentID(), equip.getEquipmentName(), equip.getEquipmentCategory(), equip.getEquipmentCostPerDay(), equip.getEquipmentDescription(), equip.getAvailabilityStatus()};
            model.addRow(rowData);
        }
    }
	
	public void updateTransactionsTable(DefaultTableModel model) {
        table.setModel(model); // Update the table in the view
    }
	
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                ViewInventoryGUI inventoryGUI = new ViewInventoryGUI();

                JFrame frame = new JFrame("Inventory Button Demo");
                frame.setSize(800, 600);
                frame.setLayout(null); // Using null layout for demonstration purposes

                JButton viewEmpButton = inventoryGUI.createButton("View Inventory", 250, 200);
                viewEmpButton.addActionListener(e -> inventoryGUI.viewInventory());

                frame.add(viewEmpButton);
                frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                frame.setVisible(true);

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}




