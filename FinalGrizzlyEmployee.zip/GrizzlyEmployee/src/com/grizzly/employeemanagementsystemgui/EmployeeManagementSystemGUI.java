package com.grizzly.employeemanagementsystemgui;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import com.grizzly.tablecreator.TableCreator;
import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;

import controller.EmployeeTasks;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.toedter.calendar.JCalendar;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.border.SoftBevelBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.border.BevelBorder;

public class EmployeeManagementSystemGUI extends JFrame{

    private JFrame menuFrame;
    private JLabel selectedDateLabel;
    private JLabel selectedStartDateLabel;
    private JLabel selectedEndDateLabel;
    EmployeeTasks empTask;

	private static final Logger logger= LogManager.getLogger(EmployeeManagementSystemGUI.class);
    private Set<String> scheduledDates = new HashSet<>();

    public EmployeeManagementSystemGUI() throws SQLException {
        initializeUI();

    }

    private void initializeUI() throws SQLException {
        menuFrame = new JFrame("Employee Management System");
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(0xFB4E7B));
        menuPanel.setLayout(null);
        menuFrame.getContentPane().add(menuPanel);


        //Action to Schedule Equipment
        JButton addEmpButton = createButton("Schedule Equipment", 400, 270);
        addEmpButton.addActionListener(e -> {
            scheduleEquipment();
        });

        JButton editEmpButton = createButton("Open Messages", 400, 340);
        editEmpButton.addActionListener(e -> {
            openMessages();
        });
        
        JButton viewInventoryButton = createButton("View Inventory", 400, 410);
        viewInventoryButton.addActionListener(e -> {
           try {
                viewInventory();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });
        
        JButton createReceiptButton = createButton("Create a Receipt", 400, 480);
        createReceiptButton.addActionListener(e -> showReceipts());

        JButton exitButton = createButton("Exit", 400, 550);
        exitButton.addActionListener(e -> {
        		menuFrame.dispose();
        		
        		EmployeeLoginGUI frame = new EmployeeLoginGUI();
				frame.setVisible(true);
        });

        menuFrame.setSize(1100, 750);
        menuFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        menuFrame.getContentPane().setLayout(null); // Using no layout managers
        menuFrame.setVisible(true);
        menuFrame.getContentPane().setBackground(new Color(61, 136, 158));
        
        JPanel panel = new JPanel();
        panel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
        panel.setBackground(new Color(86, 186, 203));
        panel.setBounds(132, 71, 843, 596);
        menuFrame.getContentPane().add(panel);
                panel.setLayout(null);
        
                JLabel welcomeLabel = new JLabel("Welcome to Grizzly's Management System");
                welcomeLabel.setBounds(159, 68, 552, 32);
                panel.add(welcomeLabel);
                welcomeLabel.setFont(new Font("Lucida Calligraphy", Font.BOLD, 23));

    }

 
    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 300, 40);
        button.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        button.setFocusPainted(false);
        menuFrame.getContentPane().add(button);
        return button;
    }

    public void viewRentalRequest() throws SQLException {
        menuFrame.setVisible(false);
    }
    
    //This frame is for scheduling equipment
    public void scheduleEquipment() {
        menuFrame.setVisible(false);

        JFrame frame = new JFrame("Schedule Equipment");
        JPanel panel = new JPanel(new GridLayout(12, 3));

        JLabel idLabel = new JLabel("Enter Customer ID");
        idLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField idVal = new JTextField();
        idVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        idVal.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                    JOptionPane.showMessageDialog(frame, "Invalid character. Please enter only numeric values.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JLabel equipmentIdLabel = new JLabel("Enter Equipment ID");
        equipmentIdLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField equipmentIdVal = new JTextField();
        equipmentIdVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        equipmentIdVal.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                    JOptionPane.showMessageDialog(frame, "Invalid character. Please enter only numeric values.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(equipmentIdLabel);
        panel.add(equipmentIdVal);

        JLabel phoneLabel = new JLabel("Enter Employee ID");
        phoneLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JTextField phoneVal = new JTextField();
        phoneVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        phoneVal.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                    JOptionPane.showMessageDialog(frame, "Invalid character. Please enter only numeric values.",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JTextField emailVal = new JTextField();
        emailVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel startDateLabel = new JLabel("Select Start Date");
        startDateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JDateChooser startDateChooser = new JDateChooser();
        startDateChooser.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent e) {
                if ("date".equals(e.getPropertyName())) {
                    updateSelectedDateLabel(startDateChooser, selectedStartDateLabel);
                }
            }

            private void updateSelectedDateLabel(JDateChooser dateChooser, JLabel label) {
                Date selectedDate = dateChooser.getDate();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String selectedDateString = sdf.format(selectedDate);
                label.setText("Selected Start Date: " + selectedDateString);
            }
        });

        selectedStartDateLabel = new JLabel("Selected Start Date: ");
        selectedStartDateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel endDateLabel = new JLabel("Select End Date");
        endDateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JDateChooser endDateChooser = new JDateChooser();
        endDateChooser.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent e) {
                if ("date".equals(e.getPropertyName())) {
                    updateSelectedDateLabel(endDateChooser, selectedEndDateLabel);
                }
            }

            private void updateSelectedDateLabel(JDateChooser dateChooser, JLabel label) {
                Date selectedDate = dateChooser.getDate();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String selectedDateString = sdf.format(selectedDate);
                label.setText("Selected End Date: " + selectedDateString);
            }
        });

        selectedEndDateLabel = new JLabel("Selected End Date: ");
        selectedEndDateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JLabel emailLabel = new JLabel("Enter Event Name");
        emailLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

        JPanel calendarPanel = new JPanel();
        calendarPanel.add(startDateLabel);
        calendarPanel.add(startDateChooser);
        calendarPanel.add(selectedStartDateLabel);
        calendarPanel.add(endDateLabel);
        calendarPanel.add(endDateChooser);
        calendarPanel.add(selectedEndDateLabel);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        backButton.addActionListener(actionListener -> {
            frame.dispose();
            menuFrame.setVisible(true);
        });
        
        //Action Listener that schedules rental
        JButton submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        submitButton.addActionListener(actionListener -> {
        	empTask=new EmployeeTasks();
            String customerId = idVal.getText();
            int parsedCustomerId = Integer.parseInt(customerId);
            
            String equipmentId = equipmentIdVal.getText();
            int parsedEquipmentId = Integer.parseInt(equipmentId);
            
            String employeeId = phoneVal.getText();
            int parsedEmployeeId = Integer.parseInt(employeeId);
            
            String eventName = emailVal.getText();
            java.util.Date selectedStartDate = startDateChooser.getDate();
            java.sql.Date sqlStartDate = new java.sql.Date(selectedStartDate.getTime());
            
            String selectedStartDateString = selectedStartDateLabel.getText().replace("Selected Start Date: ", "");
            java.util.Date selectedEndDate = endDateChooser.getDate();
            java.sql.Date sqlEndDate = new java.sql.Date(selectedEndDate.getTime());
            
            //ava.util.Date selectedEndDate = startDateChooser.getDate();
            
            empTask.sendAction("Schedule Equipment");
            empTask.sendInt(parsedCustomerId);
            empTask.sendInt(parsedEquipmentId);
            empTask.sendInt(parsedEmployeeId);
            empTask.sendDate(sqlStartDate);
            empTask.sendDate(sqlEndDate);
            empTask.sendString(eventName);
            
            
            if (customerId.isEmpty() || equipmentId.isEmpty() || employeeId.isEmpty() || eventName.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
            	Boolean flag=empTask.isScheduleResult();
            	logger.info(flag);
                if (flag==false) {
                    scheduledDates.add(selectedStartDateString);
                    String successMessage = "Equipment scheduled successfully for date: " + selectedStartDateString;
                    JOptionPane.showMessageDialog(frame, successMessage, "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    String errorMessage = "Equipment already scheduled for this date. Try again";
                    JOptionPane.showMessageDialog(frame, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        panel.add(idLabel);
        panel.add(idVal);
        panel.add(phoneLabel);
        panel.add(phoneVal);
        panel.add(emailLabel);
        panel.add(emailVal);
        panel.add(calendarPanel);
        panel.add(backButton);
        panel.add(submitButton);

        panel.setBackground(new Color(254, 251, 246));
        panel.setBorder(new EmptyBorder(50, 50, 50, 50));

        frame.getContentPane().add(panel);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1100, 750));
        frame.pack();
        frame.setVisible(true);
    }

    private void openMessages() {
        SwingUtilities.invokeLater(() -> {
            TableCreator.createAndShowGUI();
        });
    }
    
    public void viewInventory() throws SQLException {
        ViewInventoryGUI.showViewInventoryGUI();
    }
    private void showReceipts() {
        CreateReceipts.showReceiptsGUI();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new EmployeeManagementSystemGUI();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        });
    }
}