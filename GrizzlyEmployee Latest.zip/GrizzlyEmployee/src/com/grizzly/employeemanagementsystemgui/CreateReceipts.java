package com.grizzly.employeemanagementsystemgui;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public class CreateReceipts {
	
	private static JTextField customerIDField;
    private static Connection dBConn = null;

    private static Connection getDatabaseConnection() {
        if (dBConn == null) {
            try {
                String url = "jdbc:mysql://localhost:3306/grizzlycustomers";
                dBConn = DriverManager.getConnection(url, "root", "");

                JOptionPane.showMessageDialog(null, "DB Connection Established",
                        "CONNECTION STATUS", JOptionPane.INFORMATION_MESSAGE);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Could not connect to database\n" + ex,
                        "Connection Failure", JOptionPane.ERROR_MESSAGE);
            }

        }
        return dBConn;
    }

    public static void showReceiptsGUI() {
        JFrame frame = new JFrame("Generate Receipts");
        frame.setSize(400, 300);

     // Create a label and text field for entering Customer ID
        JLabel customerIDLabel = new JLabel("Customer ID:");
        customerIDField = new JTextField(20); 

     // Create a button to generate receipts
        JButton generateButton = new JButton("Generate Receipt");
        generateButton.addActionListener(e -> generateReceipts());

     // Create a panel to hold the components
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.add(customerIDLabel);
        panel.add(customerIDField);
        panel.add(generateButton);

        // Add the panel to the frame
        frame.add(panel);
        
     // Set the heading "GrizzlyEntertainment"
        JLabel headingLabel = new JLabel("GrizzlyEntertainment", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 16));
        frame.add(headingLabel, BorderLayout.NORTH);

        // Set frame properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private static void generateReceipts() {
        try {
            Connection connection = getDatabaseConnection();

            // Get Customer ID from the text field
            int customerID = Integer.parseInt(customerIDField.getText());

            // Check if customerID exists in the rentals table
            if (customerExists(connection, customerID)) {
                // Fetch records from rentals table for the given customerID
                String query = "SELECT * FROM rentals WHERE customerID = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, customerID);
                ResultSet resultSet = preparedStatement.executeQuery();

                // Display receipts in separate pop-ups
                while (resultSet.next()) {
                    displayReceiptPopup(resultSet);
                }

                // Close resources
                resultSet.close();
                preparedStatement.close();
            } else {
                // Show error message if customerID is not found
                JOptionPane.showMessageDialog(null, "Customer not found in database",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException | NumberFormatException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error processing request",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static boolean customerExists(Connection connection, int customerID) throws SQLException {
        String query = "SELECT * FROM rentals WHERE customerID = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, customerID);
        ResultSet resultSet = preparedStatement.executeQuery();
        boolean exists = resultSet.next();
        resultSet.close();
        preparedStatement.close();
        return exists;
    }

    private static void displayReceiptPopup(ResultSet resultSet) throws SQLException {
        // Extract data from the result set
        String customerName = getCustomerName(resultSet.getInt("customerID"));
        double amountPaid = resultSet.getDouble("amount_paid");
        String startDate = resultSet.getString("startdate");
        String endDate = resultSet.getString("enddate");
        String eventName = resultSet.getString("eventname");

        // Create receipt message
        String receiptMessage = "Customer: " + customerName + "\n" +
                "Amount Paid: $" + amountPaid + "\n" +
                "Start Date: " + startDate + "\n" +
                "End Date: " + endDate + "\n" +
                "Event Name: " + eventName;

        // Show receipt in a pop-up
        JOptionPane.showMessageDialog(null, receiptMessage, "Receipt", JOptionPane.INFORMATION_MESSAGE);
    }

    private static String getCustomerName(int customerID) throws SQLException {
        Connection connection = getDatabaseConnection();
        String query = "SELECT firstName, lastName FROM customers WHERE customerID = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, customerID);
        ResultSet resultSet = preparedStatement.executeQuery();
        resultSet.next();
        String firstName = resultSet.getString("firstName");
        String lastName = resultSet.getString("lastName");
        resultSet.close();
        preparedStatement.close();
        return firstName + " " + lastName;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                CreateReceipts.showReceiptsGUI();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
