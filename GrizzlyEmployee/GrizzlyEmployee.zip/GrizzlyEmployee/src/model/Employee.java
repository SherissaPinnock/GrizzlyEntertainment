package model;

public class Employee {

}
