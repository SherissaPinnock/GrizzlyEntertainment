package controller;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Date;

import javax.swing.JOptionPane;

import model.Message;

public class EmployeeTasks {
	private Socket connectionSocket;
    private ObjectOutputStream objOs;
    private ObjectInputStream objIs;
    private String action = "";
    
    
    public EmployeeTasks() {
    	this.createConnection();
    	this.configureStreams();
    }
    
    private void createConnection() {
        try {
        	//Create a socket to connect to the server
        	connectionSocket = new Socket("127.0.0.1", 3308);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void configureStreams() {
    	try {
    		//Create an input stream to receive data from the server
    		objIs = new ObjectInputStream(connectionSocket.getInputStream());
    		//Create an output stream to send data to the server
    		objOs = new ObjectOutputStream(connectionSocket.getOutputStream());
    		
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
    	try {
    		objOs.close();
    		objIs.close();
    		connectionSocket.close();
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendAction(String action) {
    	this.action = action;
    	try {
    		objOs.writeObject(action);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendMessage(Message message) {
    	try {
    		objOs.writeObject(message);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendInt(int id) {
    	try {
    		objOs.writeObject(id);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendDate(Date selectedStartDate) {
    	try {
    		objOs.writeObject(selectedStartDate);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendString(String string) {
    	try {
    		objOs.writeObject(string);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    public void receiveResponse(){
    	try {
    		if(action.equalsIgnoreCase("Schedule Equipment")) {
    			Boolean flag = (Boolean) objIs.readObject();
    			if(flag == true) {
    				JOptionPane.showMessageDialog(null, "Equipment scheduled successfully",
    						"Add Record Status", JOptionPane.INFORMATION_MESSAGE);
    			}
    	}
    	}catch (ClassCastException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
        	e.printStackTrace();
        }   
    }
}
