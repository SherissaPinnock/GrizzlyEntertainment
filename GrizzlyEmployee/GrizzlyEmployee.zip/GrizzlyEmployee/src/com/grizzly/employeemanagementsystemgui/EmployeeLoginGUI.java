package com.grizzly.employeemanagementsystemgui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.EmployeeTasks;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EmployeeLoginGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	EmployeeTasks empTask;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeLoginGUI frame = new EmployeeLoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeLoginGUI() {
		setTitle("ployee Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 329);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel titleLabel = new JLabel("GRIZZLY ENTERTAINMENT");
		titleLabel.setFont(new Font("Broadway", Font.PLAIN, 14));
		titleLabel.setBounds(23, 112, 215, 26);
		contentPane.add(titleLabel);
		
		JLabel titleLabel_1 = new JLabel("Equipment Rental");
		titleLabel_1.setFont(new Font("Broadway", Font.PLAIN, 12));
		titleLabel_1.setBounds(56, 143, 140, 14);
		contentPane.add(titleLabel_1);
		
		JLabel loginLabel = new JLabel("EMPLOYEE LOGIN");
		loginLabel.setFont(new Font("Georgia", Font.PLAIN, 14));
		loginLabel.setBounds(304, 53, 133, 14);
		contentPane.add(loginLabel);
		
		JLabel empIDLabel = new JLabel("Employee ID");
		empIDLabel.setFont(new Font("Georgia", Font.PLAIN, 12));
		empIDLabel.setBounds(304, 97, 84, 14);
		contentPane.add(empIDLabel);
		
		textField = new JTextField();
		textField.setBounds(304, 122, 96, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel empPasswordLabel = new JLabel("Employee Password");
		empPasswordLabel.setFont(new Font("Georgia", Font.PLAIN, 13));
		empPasswordLabel.setBounds(304, 176, 133, 14);
		contentPane.add(empPasswordLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(304, 201, 96, 20);
		contentPane.add(passwordField);
		
		JButton loginButton = new JButton("LOGIN");
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		loginButton.setBounds(304, 245, 89, 23);
		contentPane.add(loginButton);
	}
}
