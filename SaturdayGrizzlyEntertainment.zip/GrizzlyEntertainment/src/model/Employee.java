package model;

public class Employee {
	private int employeeID;
	private String firstName;
	private String lastName;
	private String phone;
	private String email;
	private String employeePassword;
	
	
	
	public Employee(int employeeID, String firstName, String lastName, String phone, String email) {
		this.employeeID = employeeID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.email = email;
	}
	
	public Employee() {
		this.employeeID = 0;
		this.firstName = "";
		this.lastName = "";
		this.phone = "";
		this.email = "";
	}
	
	
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
