package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import controller.ClientTasks;
import model.Customer;

import java.awt.Font;
import java.awt.Color;

public class AccountSettingsGUI extends JFrame {

	private JPanel contentPane;
	private JMenu menu;;
	private JPanel changeInfoPanel;
	private JPanel deleteAccountPanel;
	private JTextField passwordField;
	private JTextField streetField;
	private JTextField textField;
	Customer customer;

	/**
	 * Create the frame.
	 */
	public AccountSettingsGUI(Customer customer) {
		ClientTasks task= new ClientTasks();
		this.customer = customer;
		setTitle("Account Settings");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 409, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(162, 197, 121));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		// Create panels for each option
        changeInfoPanel = new JPanel();
        changeInfoPanel.add(new JLabel("Change Info Panel"));

        deleteAccountPanel = new JPanel();
        deleteAccountPanel.add(new JLabel("Delete Account Panel"));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 395, 22);
		contentPane.add(menuBar);

	     // Create a menu
	     JMenu accountMenu = new JMenu("Account");

	     // Create menu items
	     JMenuItem changeInfoItem = new JMenuItem("Change Info");
	     JMenuItem deleteAccountItem = new JMenuItem("Delete Account");
	     
	     // Add menu items to the menu
	        accountMenu.add(changeInfoItem);
	        accountMenu.add(deleteAccountItem);

	        // Add the menu to the menu bar
	        menuBar.add(accountMenu);
	        
	        JLabel lblNewLabel = new JLabel("Change Password");
	        lblNewLabel.setFont(new Font("Georgia", Font.PLAIN, 13));
	        lblNewLabel.setBounds(21, 50, 111, 22);
	        contentPane.add(lblNewLabel);
	        
	        passwordField = new JTextField();
	        passwordField.setBounds(142, 52, 123, 20);
	        contentPane.add(passwordField);
	        passwordField.setColumns(10);
	        
	        JLabel lblNewLabel_1 = new JLabel("Change Email");
	        lblNewLabel_1.setFont(new Font("Georgia", Font.PLAIN, 13));
	        lblNewLabel_1.setBounds(21, 95, 111, 20);
	        contentPane.add(lblNewLabel_1);
	        
	        streetField = new JTextField();
	        streetField.setBounds(142, 96, 123, 20);
	        contentPane.add(streetField);
	        streetField.setColumns(10);
	        
	        JLabel lblNewLabel_4 = new JLabel("Change Phone");
	        lblNewLabel_4.setFont(new Font("Georgia", Font.PLAIN, 13));
	        lblNewLabel_4.setBounds(21, 143, 96, 18);
	        contentPane.add(lblNewLabel_4);
	        
	        textField = new JTextField();
	        textField.setBounds(142, 143, 123, 20);
	        contentPane.add(textField);
	        textField.setColumns(10);
	        // Add action listeners to menu items
	        changeInfoItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                // Add your code for "Change Info" here
	                JOptionPane.showMessageDialog(AccountSettingsGUI.this, "Change Info selected");
	                setContentPane(changeInfoPanel);
	                revalidate();
	                repaint();
	            }
	        });

	        deleteAccountItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	
	            	setContentPane(deleteAccountPanel);
	                revalidate();
	                repaint();
	                // Add your code for "Delete Account" here
	                int choice = JOptionPane.showConfirmDialog(AccountSettingsGUI.this, "Are you sure you want to delete your account?",
	                        "Confirm Deletion", JOptionPane.YES_NO_OPTION);
	                if (choice == JOptionPane.YES_OPTION) {
	                    JOptionPane.showMessageDialog(AccountSettingsGUI.this, "Account deleted");
	                    task.sendAction("Delete Account");
	                    task.sendCustomerId(customer.getCustomerID());
	                    System.out.println("Sent "+ customer.getCustomerID());
	                    task.receiveResponse();
	                    MainWindow main= new MainWindow();
	    				main.setVisible(true);
	    				setVisible(false);
	                }
	            }
	        });
	}
}
