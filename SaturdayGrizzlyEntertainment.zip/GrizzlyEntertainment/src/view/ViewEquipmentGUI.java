package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import com.toedter.calendar.JDateChooser;// this allows for the customer to select a date from the calendar


import model.Customer;
import model.Equipment;
import controller.ClientTasks;
import javax.swing.JScrollPane;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.List;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;

public class ViewEquipmentGUI extends JFrame {

  private static final long serialVersionUID = 1L;
  private JPanel contentPane;
  private JDateChooser startDatePicker; 
  private JDateChooser endDatePicker; 
  private JTextField equipmentIdField;
  private JLabel idLabel;
  JTable equipmentTable = new JTable();
  JScrollPane scrollPane = new JScrollPane(); 
  /**
   * Launch the application.
   */
  /**
   * Create the frame.
   */
  public ViewEquipmentGUI(JFrame dashboardFrame) {


    contentPane = new JPanel();
    contentPane.setBackground(new Color(102, 204, 255));
    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
    setBounds(100, 100, 743, 578);
    setContentPane(contentPane);
    contentPane.setLayout(null);

    setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

    JComboBox<String> categoryComboBox = new JComboBox<String>();
    categoryComboBox.setBounds(5, 5, 719, 25);
    categoryComboBox.setBackground(new Color(255, 255, 255));
    categoryComboBox.setFont(new Font("Arial Rounded MT Bold", Font.BOLD | Font.ITALIC, 15));
    categoryComboBox.setModel(new DefaultComboBoxModel(new String[] {"Staging ", "Lighting", "Sound", "Power"}));

    contentPane.add(categoryComboBox);

    //action listener for comboBox that allows the user to select from the drop down list a category and 
    //when it is selected the retrieve equipment database is called and it will display all the available data
    //based on the category selected.
    categoryComboBox.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
            	ClientTasks task= new ClientTasks();
            	
              String selectedCategory = (String) categoryComboBox.getSelectedItem(); 
              
              
              task.sendAction("View Equipment");
              task.sendCustomerPassword(selectedCategory);
              task.sendCustomerPassword("Available");
              task.receiveResponse();
              List<Equipment> equipments = task.getReceivedEquipment(); //Corrected
              
              DefaultTableModel model = convertListToTableModel(equipments);// calls the convert method at the bottom of this code and
                                               //stores the data in a model object

              equipmentTable.setModel(model);//this will set the equipment table(JTable) to the values stored in the model object

              scrollPane.setViewportView(equipmentTable);// this allows the JTable to be shown on the scoll pane
              scrollPane.setBounds(5, 167, 724, 91);
              contentPane.add(scrollPane);//adds the scroll pane to the content pane so that users can see the data
            }
    });


    JLabel lblNewLabel = new JLabel("Available Equipments");
    lblNewLabel.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 17));
    lblNewLabel.setBounds(244, 104, 210, 25);
    contentPane.add(lblNewLabel);
    
    JLabel idLabel= new JLabel("Enter equipment Id to query");
    idLabel.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 17));
    idLabel.setBounds(10, 250, 210, 25);
    contentPane.add(idLabel);
    
    equipmentIdField= new JTextField();
    equipmentIdField.setBounds(230, 250, 210, 25);
    contentPane.add(equipmentIdField);
    
    

    JLabel dateLabel1 = new JLabel("Select start date");
    dateLabel1.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 17));
    dateLabel1.setBounds(10, 386, 210, 25);
    contentPane.add(dateLabel1);

    startDatePicker= new JDateChooser(); //this allows a calendar to pop up so that the user can choose a date
    startDatePicker.setBounds(172,381,150,30);
    contentPane.add(startDatePicker);

    JLabel dateLabel2 = new JLabel("Select end date");
    dateLabel2.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 17));
    dateLabel2.setBounds(10, 442, 210, 25);
    contentPane.add(dateLabel2);

    endDatePicker= new JDateChooser(); //this allows a calendar to pop up so that the user can choose a date
    endDatePicker.setBounds(172,437,150,30);
    contentPane.add(endDatePicker);

    JButton checkButton = new JButton("Check Availability");// this button will have an action listener that carries out a function
    checkButton.setBounds(5, 509, 719, 27);
    checkButton.setFont(new Font("Arial Rounded MT Bold", Font.BOLD | Font.ITALIC, 15));
    contentPane.add(checkButton);

    //this action listener needs to be done properly
    checkButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        //compare the two dates and then subtract them from each other in order to get the total amount of days needed
        //the dates will be needed in order to calculate the quoation because you would have the cost per day * the number of days

//				compare the two dates in the transcation database with the dates selected by the user 
//				create a if statement based on the start and end date of each reuqest and if the date has already be selected print
        //an error message else print that the date is available then generate the quotation 
//				
//				if()
//				{
//					
//				}
//				int numOfDays= startDate - endDate; 
//				Equipment equip= new Equipment();
//				double quotation= equip.getEquipmentCostPerDay() * numOfDays; 
//				
//				JOptionPane.showMessageDialog(null, "Date available. Quotation on Cost= " + quotation);
    	  java.util.Date startDateUtil = startDatePicker.getDate();
    	  java.sql.Date sqlStartDate = new java.sql.Date(startDateUtil.getTime());

    	  // Assuming endDatePicker.getDate() returns a java.util.Date
    	  java.util.Date endDateUtil = endDatePicker.getDate();
    	  java.sql.Date sqlEndDate = new java.sql.Date(endDateUtil.getTime());

          
          ClientTasks task= new ClientTasks();
          task.sendAction("Check Availability");
          String equipmentId=equipmentIdField.getText();
          int equipmentIdInt = Integer.parseInt(equipmentId);
          task.sendCustomerId(equipmentIdInt);
          task.sendDate(sqlStartDate);
          task.sendDate(sqlEndDate);
          task.receiveResponse();
         
          
          
          
          //task.sendCustomerId();
      }
    });




  }

  //this is used to convert the array list from the database to a 2d array so that it can be stored in the JTable
  public DefaultTableModel convertListToTableModel(List<Equipment> equipments) {

    // Define column names for the table model
      String[] columnNames = {"Equipment ID", "Name", "Category", "Cost Per Day", "Description", "Availability Status"};

      // Create the table model and set column identifiers
      DefaultTableModel model = new DefaultTableModel();
      model.setColumnIdentifiers(columnNames);

      // Populate the table model with data
      for (Equipment equipment : equipments) {
          Object[] rowData = new Object[] {
              equipment.getEquipmentID(),
              equipment.getEquipmentName(),
              equipment.getEquipmentCategory(),
              equipment.getEquipmentCostPerDay(),
              equipment.getEquipmentDescription(),
              equipment.getAvailabilityStatus()
          };
          model.addRow(rowData);
      }

      return model;
  }

}
