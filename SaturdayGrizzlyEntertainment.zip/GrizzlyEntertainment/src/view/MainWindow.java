package view;

import java.awt.EventQueue;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import controller.ClientTasks;
import model.Customer;
import model.Employee;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JComponent;

public class MainWindow extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField idTextField;
	private JPasswordField passwordField;
	private String[] userOption={"Customer", "Employee"};
	private ClientTasks task;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					
					
					
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainWindow() {
		//task = new ClientTasks();
		
		setForeground(new Color(1, 106, 112));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 466);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(1, 106, 112));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel titleLabel = new JLabel("Grizzly Entertainment ");
		titleLabel.setForeground(new Color(255, 255, 221));
		titleLabel.setFont(new Font("Broadway", Font.PLAIN, 21));
		titleLabel.setBounds(39, 144, 280, 44);
		contentPane.add(titleLabel);
		
		
		JComboBox OptionComboBox = new JComboBox<String>(userOption);
		OptionComboBox.setBounds(376, 252, 82, 22);
		contentPane.add(OptionComboBox);
		
		//Action Listener for the Sign Up button
		JButton registerBtn = new JButton("Sign Up");
		registerBtn.setBackground(new Color(210, 222, 50));
		registerBtn.setBounds(466, 341, 82, 30);
		contentPane.add(registerBtn);
		
		 registerBtn.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                // Check the selected option in the JComboBox
	                String selectedOption = OptionComboBox.getSelectedItem().toString();
	           
	                if ("Customer".equals(selectedOption)) {
	                    // Open the Customer Registration window
	                    CustomerRegistration customerRegister = new CustomerRegistration(MainWindow.this);
	                    customerRegister.setVisible(true);
	                    
	                    setVisible(false);
	                } else if ("Employee".equals(selectedOption)) {
	                    //Open the Employee Registration Window
	                	
	                }
	            }
	        });
		
		
		 JButton loginBtn = new JButton("Login");
		//Action Listener for the Login button
		// Existing code...

		// Action for the Login button
		Action loginAction = new AbstractAction("Login") {
		    @Override
		   public void actionPerformed(ActionEvent e) {
		        // Code to execute when the Login button is triggered
		        String id = idTextField.getText();
		        String password = new String(passwordField.getPassword());

		        // Check the selected option in the JComboBox
		        String selectedOption = OptionComboBox.getSelectedItem().toString();

		        if ("Customer".equals(selectedOption)) {
		        	// Send the login request
		        	task= new ClientTasks();
		        	
		        	//Create a blank customer object that can hold the id and password. 
		        	Customer customer = new Customer();
		        	int intID= Integer.valueOf(id);
		        	customer.setCustomerID(intID);
		        	customer.setCustomerpassword(password);
		        	task.sendAction("Customer Login");
		        	task.sendCustomer(customer); // Send the customer object

		        	task.receiveResponse();
		        	boolean loginResult = task.getLoginResult();
		        	System.out.println(loginResult);
		        	
		            if (loginResult) {
		                //If Login is successful, open the Customer Dashboard
		            	//Send Action to Server
		            	ClientTasks task= new ClientTasks();
		            	task.sendAction("Get Customer Details");
		            	System.out.println("Sending action");
		            	
		            	//Send id to server
		            	task.sendCustomerId(customer.getCustomerID());
		            	System.out.println("Sent "+ customer.getCustomerID());
		            	 // Receive and store the customer details from the server
		            	task.receiveResponse(); //Corrected
		            	Customer receivedCustomer = task.getReceivedCustomer();
		            	System.out.println(receivedCustomer);
		            	
		            	
		                System.out.println("Customer Login successful! Opening customer dashboard...");
		                CustomerDashboardGUI custDashboard = new CustomerDashboardGUI(MainWindow.this, receivedCustomer);
		                custDashboard.setVisible(true);
		                setVisible(false);
		            } else {
		                // Display an error message if the login fails.
		                JOptionPane.showMessageDialog(null, "Customer Login failed. Invalid ID or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
		                System.out.println("Customer Login failed. Invalid ID or password.");
		                
		            }
		        } else if ("Employee".equals(selectedOption)) {
		            // Validate employee login
		            boolean loginSuccessful = ClientTasks.validateEmployeeLogin(id, password);

		            if (loginSuccessful) {
		                // If Employee Login is successful, handle employee dashboard or functionality here.
		                System.out.println("Employee Login successful! Opening employee dashboard...");
		                Employee employee = ClientTasks.getEmployeeDetails(id);

		                // Add code for the employee's dashboard or other functionality.
		                EmployeeDashboard empDashboard = new EmployeeDashboard(MainWindow.this, employee);
		                empDashboard.setVisible(true);
		                setVisible(false);
		            } else {
		                // Display an error message if the login fails.
		                JOptionPane.showMessageDialog(null, "Employee Login failed. Invalid ID or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
		                System.out.println("Employee Login failed. Invalid ID or password.");
		                
		            }
		        }
		    }
		};

	
		// Set an action command for the Login button
		loginBtn.setAction(loginAction);
		// Define the Ctrl+L key binding for the Login action
		loginAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control L"));
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
		    KeyStroke.getKeyStroke("control L"), "loginAction"
		);
		getRootPane().getActionMap().put("loginAction", loginAction);



		loginBtn.setBackground(new Color(210, 222, 50));
		loginBtn.setBounds(376, 300, 82, 30);
		contentPane.add(loginBtn);
		
		JLabel title2 = new JLabel("Equipment Rental");
		title2.setForeground(new Color(162, 197, 121));
		title2.setFont(new Font("Broadway", Font.PLAIN, 15));
		title2.setBounds(95, 177, 159, 25);
		contentPane.add(title2);
		
		JLabel loginLbl = new JLabel("LOGIN");
		loginLbl.setFont(new Font("Tahoma", Font.PLAIN, 18));
		loginLbl.setBounds(432, 72, 66, 30);
		contentPane.add(loginLbl);
		
		JLabel idLbl = new JLabel("ID");
		idLbl.setFont(new Font("Tahoma", Font.PLAIN, 13));
		idLbl.setBounds(376, 113, 82, 25);
		contentPane.add(idLbl);
		
		idTextField = new JTextField();
		idTextField.setBounds(376, 144, 149, 20);
		contentPane.add(idTextField);
		idTextField.setColumns(10);
		idTextField.setToolTipText("Enter ID here");
		
		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		passwordLabel.setBounds(376, 182, 59, 14);
		contentPane.add(passwordLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(376, 207, 149, 20);
		contentPane.add(passwordField);
		// Add a tooltip for the password field
		passwordField.setToolTipText("Enter Password");
		
		JLabel signUpLbl = new JLabel("No account?");
		signUpLbl.setBounds(376, 349, 91, 14);
		contentPane.add(signUpLbl);
		
		JLabel imageLabel = new JLabel("");
		ImageIcon icon = new ImageIcon("/Boombox.png"); // Replace "path_to_your_image.png" with the actual path to your image file.
		imageLabel.setIcon(icon);
		imageLabel.setBounds(61, 226, 213, 145);
		contentPane.add(imageLabel);
		
		// This is so when I press Ctrl+Q key to exit the frame
		Action exitAction = new AbstractAction("Exit") {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        System.exit(0); // Exit the application
		    }
		};

		// Set an action command for the Exit action
		exitAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control Q"));
		getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
		    KeyStroke.getKeyStroke("control Q"), "exitAction"
		);
		getRootPane().getActionMap().put("exitAction", exitAction);
		
		//task = new ClientTasks();
	}
}
