package view;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import controller.ClientTasks;
import model.Customer;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EtchedBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;

public class CustomerDashboardGUI extends JFrame {
	
	private static final Logger logger= LogManager.getLogger(CustomerDashboardGUI.class);

	private JPanel contentPane;
	private final JPanel panel = new JPanel();
	private Customer customer;
	private ClientTasks task;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
				
					//CustomerDashboardGUI frame = new CustomerDashboardGUI(frame);
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerDashboardGUI(JFrame mainFrame, Customer customer) {
		setTitle("Grizzly Dashboard");
		
		// Store the customer object
		ClientTasks task= new ClientTasks();
        this.customer = customer;
        
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 916, 525);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(1, 106, 112));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		panel.setBackground(new Color(255, 255, 221));
		panel.setBounds(10, 0, 271, 488);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel bannerPanel = new JPanel();
		bannerPanel.setBackground(new Color(210, 222, 50));
		bannerPanel.setBounds(0, 11, 903, 57);
		panel.add(bannerPanel);
		bannerPanel.setLayout(null);
		
		System.out.print(customer);
		JLabel welcomelbl = new JLabel("WELCOME " + customer.getFirstName());
		welcomelbl.setFont(new Font("Georgia", Font.PLAIN, 21));
		welcomelbl.setBounds(23, 21, 236, 25);
		bannerPanel.add(welcomelbl);
		
		JLabel lblNewLabel = new JLabel("Customer Dashboard");
		lblNewLabel.setFont(new Font("Georgia", Font.PLAIN, 21));
		lblNewLabel.setBounds(28, 176, 233, 74);
		panel.add(lblNewLabel);
		
		JButton logoutButton = new JButton("LOGOUT");
		logoutButton.setFont(new Font("Georgia", Font.PLAIN, 13));
		logoutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainWindow main= new MainWindow();
				main.setVisible(true);
				setVisible(false);
			}
		});
		logoutButton.setBounds(79, 376, 89, 23);
		panel.add(logoutButton);
		
		//Action Listener for view products
		JPanel viewPanel = new JPanel();
		viewPanel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		viewPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("View Products was clicked");
				ViewEquipmentGUI viewEquipment= new ViewEquipmentGUI(CustomerDashboardGUI.this);
				viewEquipment.setVisible(true);
			}
		});
		viewPanel.setBounds(336, 76, 207, 150);
		contentPane.add(viewPanel);
		viewPanel.setLayout(null);
		
		JLabel viewProductsLbl = new JLabel("View Products");
		viewProductsLbl.setFont(new Font("Georgia", Font.BOLD, 21));
		viewProductsLbl.setBounds(23, 63, 160, 41);
		viewPanel.add(viewProductsLbl);
		
		//Action Listener for view transactions
		JPanel transactionPanel = new JPanel();
		transactionPanel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		transactionPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("This was clicked");
				ViewTransactionsGUI transactionsGUI= new ViewTransactionsGUI(task, customer);
				
				transactionsGUI.setVisible(true);
			}
		});
		transactionPanel.setBounds(649, 76, 207, 150);
		contentPane.add(transactionPanel);
		transactionPanel.setLayout(null);
		
		JLabel transactionsLbl = new JLabel("My Transactions");
		transactionsLbl.setFont(new Font("Georgia", Font.BOLD, 21));
		transactionsLbl.setBounds(10, 67, 187, 25);
		transactionPanel.add(transactionsLbl);
		
		JPanel rentPanel = new JPanel();
		rentPanel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, new Color(255, 255, 0), null, null, null));
		rentPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		rentPanel.setBounds(336, 288, 204, 150);
		contentPane.add(rentPanel);
		rentPanel.setLayout(null);
		
		JLabel settingsLbl = new JLabel("Account Settings");
		settingsLbl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AccountSettingsGUI settings=new AccountSettingsGUI(customer);
				settings.setVisible(true);
			}
		});
		settingsLbl.setFont(new Font("Georgia", Font.BOLD, 21));
		settingsLbl.setBounds(10, 24, 184, 115);
		rentPanel.add(settingsLbl);
		
		JPanel messagePanel = new JPanel();
		messagePanel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		 messagePanel.addMouseListener(new MouseAdapter() {
		      @Override
		      public void mouseClicked(MouseEvent e) {
		        SendMessageGUI message = new SendMessageGUI(CustomerDashboardGUI.this, customer);
		        message.setVisible(true);
		      }
		    });
		messagePanel.setBounds(649, 288, 207, 150);
		contentPane.add(messagePanel);
		messagePanel.setLayout(null);
		
		JLabel messageLbl = new JLabel("Messages");
		messageLbl.setFont(new Font("Georgia", Font.BOLD, 21));
		messageLbl.setBounds(49, 69, 105, 23);
		messagePanel.add(messageLbl);
	}
}
