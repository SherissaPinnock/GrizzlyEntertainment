package view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import com.toedter.calendar.JDateChooser; // Import the JDateChooser library

import controller.ClientTasks;
import model.Customer;

import javax.swing.JLabel;
import javax.swing.JTable;
import java.awt.Font;

public class CustomerViewEquipmentGUI extends JFrame {

    private JPanel contentPane;
    private JDateChooser datePicker;
    private ClientTasks task;
    private Customer customer;
    private JTable equipmentTable;

    
    public CustomerViewEquipmentGUI(ClientTasks task, Customer customer) {
    	this.customer=customer;
    	this.task=task;
    	
    	setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        setBounds(100, 100, 910, 500);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JMenuBar menuBar = new JMenuBar();
        menuBar.setBounds(0, 11, 904, 22);
        contentPane.add(menuBar);

        JMenu categoriesMenu = new JMenu("Categories");
        menuBar.add(categoriesMenu);

        JMenuItem lightingMenuItem = new JMenuItem("Lighting");
        JMenuItem stagingMenuItem = new JMenuItem("Staging");
        JMenuItem powerMenuItem = new JMenuItem("Power");
        JMenuItem soundMenuItem = new JMenuItem("Sound");

        categoriesMenu.add(lightingMenuItem);
        categoriesMenu.add(stagingMenuItem);
        categoriesMenu.add(powerMenuItem);
        categoriesMenu.add(soundMenuItem);

        lightingMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement action when "Lighting" is selected
                // Update the equipment list based on the selected category.
            }
        });

        datePicker = new JDateChooser();
        datePicker.setBounds(22, 265, 150, 30);
        contentPane.add(datePicker);

        JLabel dateLabel = new JLabel("Select Date:");
        dateLabel.setBounds(10, 10, 100, 20);
        contentPane.add(dateLabel);
        
        equipmentTable = new JTable();
        equipmentTable.setBounds(224, 80, 604, 333);
        contentPane.add(equipmentTable);
        
        JLabel checkDateLabel = new JLabel("Check Availability");
        checkDateLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
        checkDateLabel.setBounds(22, 240, 112, 14);
        contentPane.add(checkDateLabel);
    }
}
