package view;

import java.awt.Color;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.toedter.calendar.demo.JCalendarDemo;

import controller.ClientTasks;
import model.Customer;
import model.Employee;

public class EmployeeDashboard extends JFrame {

	private JPanel contentPane;
	private Employee employee;
	private ClientTasks task;
	private JFrame menuFrame;
	private JCalendarDemo miniCalendar;
	//private static final Logger logger= LogManager.getLogger(EmployeeDashboard.class);
	
	/**
	 * Create the frame.
	 */
	public EmployeeDashboard(JFrame mainFrame, Employee employee) {
	        initializeUI();
	    }

	    private void initializeUI(){
	        menuFrame = new JFrame("Employee Management System");

	        JLabel welcomeLabel = new JLabel("Welcome to Grizzly's Management System");
	        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 32));
	        welcomeLabel.setBounds(250, 50, 800, 50);
	        menuFrame.add(welcomeLabel);

	        JButton viewEmpButton = createButton("View all rental Requests", 400, 200);
	        viewEmpButton.addActionListener(e -> {
	          //new function
	            viewEmployee();
	        });

	        JButton viewEquipButton = createButton("View all Equipments", 400, 200);
	        viewEquipButton.addActionListener(e -> {
	          //new function
	            viewEquipment();
	        });

	        JButton addEmpButton = createButton("Schedule Equipment", 400, 270);
	        addEmpButton.addActionListener(e -> {
	            addEmployee();
	        });

	        JButton editEmpButton = createButton("Open Messages", 400, 340);
	        editEmpButton.addActionListener(e -> {
	            editEmployee();
	        });

	        JButton deleteEmpButton = createButton("Create Invoice", 400, 410);
	        deleteEmpButton.addActionListener(e -> deleteEmployee());

	        JButton exitButton = createButton("Exit", 400, 480);
	        exitButton.addActionListener(e -> menuFrame.dispose());

	        menuFrame.setSize(1100, 750);
	        menuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        menuFrame.setLayout(null); // Using no layout managers
	        menuFrame.setVisible(true);
	    }

	    private void viewEquipment() {
	    // TODO Auto-generated method stub

	  }

	  private JButton createButton(String text, int x, int y) {
	        JButton button = new JButton(text);
	        button.setBounds(x, y, 300, 40);
	        button.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	        button.setFocusPainted(false);
	        menuFrame.add(button);
	        return button;
	    }

	    public void viewEmployee() {
	        menuFrame.setVisible(false);

	        JFrame frame = new JFrame("Employee Records");
	        JPanel panel = new JPanel();
	//connect to database
	        // Example data (you can replace this with your own data)
	        String[] employeeNames = {"John Doe", "Jane Smith", "Alice Johnson"};
	        String[] genders = {"Male", "Female", "Female"};
	        String[] phoneNumbers = {"123-456-7890", "987-654-3210", "555-555-5555"};
	        String[] emails = {"john@example.com", "jane@example.com", "alice@example.com"};
//	        String[] designations = {"Manager", "Assistant", "Supervisor"};
//	        double[] salaries = {60000, 45000, 55000};

	        for (int i = 0; i < employeeNames.length; i++) {
	            JPanel employeeCard = new JPanel();

	            JLabel nameLabel = new JLabel("Name");
	            nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            JLabel nameVal = new JLabel(employeeNames[i]);
	            nameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            JLabel genderLabel = new JLabel("Gender");
	            genderLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            JLabel genderVal = new JLabel(genders[i]);
	            genderVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            JLabel phoneLabel = new JLabel("Phone Number");
	            phoneLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            JLabel phoneVal = new JLabel(phoneNumbers[i]);
	            phoneVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            JLabel emailLabel = new JLabel("Email");
	            emailLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            JLabel emailVal = new JLabel(emails[i]);
	            emailVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

//	            JLabel designationLabel = new JLabel("Designation");
//	            designationLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	//
//	            JLabel designationVal = new JLabel(designations[i]);
//	            designationVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	//
//	            JLabel salaryLabel = new JLabel("Salary");
//	            salaryLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	//
//	            JLabel salaryVal = new JLabel(String.valueOf(salaries[i]));
//	            salaryVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	            employeeCard.add(nameLabel);
	            employeeCard.add(nameVal);
	            employeeCard.add(genderLabel);
	            employeeCard.add(genderVal);
	            employeeCard.add(phoneLabel);
	            employeeCard.add(phoneVal);
	            employeeCard.add(emailLabel);
	            employeeCard.add(emailVal);
//	            employeeCard.add(designationLabel);
//	            employeeCard.add(designationVal);
//	            employeeCard.add(salaryLabel);
//	            employeeCard.add(salaryVal);

	            employeeCard.setSize(1000, 400);
	            employeeCard.setBackground(new Color(166, 209, 230));
	            employeeCard.setBorder(new EmptyBorder(20, 50, 20, 50));
	            GridLayout cardLayout = new GridLayout(0, 2);
	            cardLayout.setHgap(5);
	            cardLayout.setVgap(10);
	            employeeCard.setLayout(cardLayout);
	            panel.add(employeeCard);
	        }

	        JPanel buttonPanel = new JPanel();
	        JButton backButton = new JButton("Back");
	        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	        backButton.setBounds(450, 30, 200, 50);
	        backButton.setFocusPainted(false);

	        backButton.addActionListener(actionListener -> {
	            frame.dispose();
	            menuFrame.setVisible(true);
	        });
	        buttonPanel.add(backButton);
	        buttonPanel.setLayout(null);
	        buttonPanel.setBackground(new Color(254, 251, 246));
	        panel.add(buttonPanel);

	        GridLayout layout = new GridLayout(0, 1);
	        layout.setVgap(30);
	        panel.setLayout(layout);
	        panel.setBackground(new Color(254, 251, 246));
	        panel.setBorder(new EmptyBorder(50, 0, 50, 0));

	        JScrollPane scrollBar = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	        frame.add(scrollBar);
	        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	        frame.setPreferredSize(new Dimension(1100, 750));
	        frame.pack();
	        frame.setVisible(true);
	    }


	    public void addEmployee() {
	        menuFrame.setVisible(false);

	        JFrame frame = new JFrame("Schedule Equipment");
	       // JPanel panel = new JPanel();
	        JPanel panel = new JPanel(new GridLayout(12, 2));

	        JLabel idLabel = new JLabel("Enter ID");
	        idLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JTextField idVal = new JTextField();
	        idVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JLabel nameLabel = new JLabel("Enter Name");
	        nameLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JTextField nameVal = new JTextField();
	        nameVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

//	        JLabel genderLabel = new JLabel("E");
//	        genderLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	//
//	        JComboBox<String> genderVal = new JComboBox<>(new String[]{"Staging", "Lighting", "Power", "Sound"});
//	        genderVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JLabel phoneLabel = new JLabel("Enter Phone Number");
	        phoneLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JTextField phoneVal = new JTextField();
	        phoneVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JLabel emailLabel = new JLabel("Enter Email Address");
	        emailLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JTextField emailVal = new JTextField();
	        emailVal.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JLabel dateLabel = new JLabel("Select Reservation Date");
	        dateLabel.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        JButton reserveDateButton = new JButton("Click me to Reserve Date");
	        reserveDateButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));
	        reserveDateButton.setBounds(450, 480, 200, 50);
	        reserveDateButton.setFocusPainted(false);

	        reserveDateButton.addActionListener(actionEvent -> {
	           this.miniCalendar = new JCalendarDemo();
	            miniCalendar.setVisible(true);
	        });


	        JButton backButton = new JButton("Back");
	        backButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        backButton.addActionListener(actionListener -> {
	            frame.dispose();
	            menuFrame.setVisible(true);
	        });

	        JButton submitButton = new JButton("Submit");
	        submitButton.setFont(new Font("Times New Roman", Font.PLAIN, 20));

	        submitButton.addActionListener(actionListener -> {
	            // Validate user input
	            String idStr = idVal.getText();
	            String name = nameVal.getText();
	            String phoneNum = phoneVal.getText();
	            String email = emailVal.getText();

	        });

	        // Add components to the panel
	        panel.add(idLabel);
	        panel.add(idVal);
	        panel.add(nameLabel);
	        panel.add(nameVal);
//	        panel.add(genderLabel);
//	        panel.add(genderVal);
	        panel.add(phoneLabel);
	        panel.add(phoneVal);
	        panel.add(emailLabel);
	        panel.add(emailVal);
	        panel.add(dateLabel);

	        panel.add(reserveDateButton);

	        panel.add(backButton);
	        panel.add(submitButton);

	        panel.setBackground(new Color(254, 251, 246));
	        panel.setBorder(new EmptyBorder(50, 50, 50, 50));

	        frame.add(panel);
	        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	        frame.setPreferredSize(new Dimension(1100, 750));
	        frame.pack();
	        frame.setVisible(true);
	    }

	    private void editEmployee() {
	        // Implement your editEmployee logic here
	    }

	    private void deleteEmployee() {
	        // Implement your deleteEmployee logic here
	    }
	
	}


	    
	    
	


	


