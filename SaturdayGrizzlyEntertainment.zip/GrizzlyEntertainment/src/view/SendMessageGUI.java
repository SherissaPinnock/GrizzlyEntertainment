package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import model.Customer;
import model.Message;
import controller.ClientTasks;

public class SendMessageGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	  private JPanel contentPane;
	  private JTextField lastNameTextField;
	  private JTextField firstNameTextField;
	  private Customer customer;
	  private ClientTasks task;
	  /**
	   * Create the frame.
	   */

	  public SendMessageGUI(JFrame dashboardFrame, Customer customer) {

	    this.customer = customer;

	    // Add a window listener to handle the window closing event
	    addWindowListener(new WindowAdapter() {
	      @Override
	      public void windowClosing(WindowEvent e) {
	        // Set the dashboard to visible when the sendMessage window is closed
	        dashboardFrame.setVisible(true);

	      }
	    });
	    setTitle("Send Message");
	    setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	    setBounds(100, 100, 690, 641);
	    contentPane = new JPanel();
	    contentPane.setBackground(new Color(51, 102, 153));
	    contentPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));

	    setContentPane(contentPane);
	    contentPane.setLayout(null);

	    JLabel lblNewLabel = new JLabel("Welcome to the Equipment Enquiry System");
	    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 26));
	    lblNewLabel.setBounds(86, 23, 510, 100);
	    contentPane.add(lblNewLabel);

	    JLabel firstNameLabel = new JLabel("Enter First Name: ");
	    firstNameLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
	    firstNameLabel.setBounds(38, 168, 221, 32);
	    contentPane.add(firstNameLabel);

	    JLabel lastNameLabel = new JLabel("Enter Last Name: ");
	    lastNameLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
	    lastNameLabel.setBounds(38, 241, 221, 32);
	    contentPane.add(lastNameLabel);

	    firstNameTextField = new JTextField();
	    firstNameTextField.setBounds(328, 168, 242, 32);
	    contentPane.add(firstNameTextField);
	    firstNameTextField.setColumns(10);

	    lastNameTextField = new JTextField();
	    lastNameTextField.setBounds(328, 243, 242, 32);
	    contentPane.add(lastNameTextField);
	    lastNameTextField.setColumns(10);

	    JLabel lblNewLabel_3 = new JLabel("Please leave your message below");
	    lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 20));
	    lblNewLabel_3.setBounds(38, 316, 376, 40);
	    contentPane.add(lblNewLabel_3);

	    JTextArea textArea = new JTextArea();
	    textArea.setBounds(38, 380, 430, 181);
	    contentPane.add(textArea);

	    JButton submit = new JButton("Submit");
	    submit.setMnemonic('S');
	    submit.setBackground(new Color(255, 255, 255));
	    submit.setFont(new Font("Times New Roman", Font.PLAIN, 18));
	    submit.setBounds(530, 447, 89, 23);
	    contentPane.add(submit);

	    submit.addActionListener(new ActionListener() {
	      public void actionPerformed(ActionEvent e) {

	        String firstName = firstNameTextField.getText();
	        String lastName = lastNameTextField.getText();
	        String message = textArea.getText();
	        Message sentMessage = new Message(firstName, lastName, message);
	        
	        ClientTasks task=new ClientTasks();
	        task.sendAction("Insert Message");
	        task.sendCustomer(customer);
	        task.sendMessage(sentMessage);
        	task.receiveResponse();
	        
	        if (sentMessage == null) {
	          JOptionPane.showMessageDialog(null, "There was problem saving your message");
	          System.out.println("There was problem saving your message");

	        }

	      }
	    });

	  }
	}


