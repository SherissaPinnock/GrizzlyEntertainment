package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import model.Customer;
import model.Message;
import controller.ClientTasks;

public class SendMessageGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	  private JPanel contentPane;
	  private JTextField lastNameTextField;
	  private JTextField firstNameTextField;
	  private JTextArea myMessagesTextArea;
	  private Customer customer;
	  private ClientTasks task;
	  /**
	   * Create the frame.
	   */

	  public SendMessageGUI(JFrame dashboardFrame, Customer customer) {
		 
	    this.customer = customer;

	    // Add a window listener to handle the window closing event
	    addWindowListener(new WindowAdapter() {
	      @Override
	      public void windowClosing(WindowEvent e) {
	        // Set the dashboard to visible when the sendMessage window is closed
	        dashboardFrame.setVisible(true);

	      }
	    });
	    setTitle("Send Message");
	    setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	    setBounds(100, 100, 690, 641);
	    contentPane = new JPanel();
	    contentPane.setBackground(new Color(51, 102, 153));
	    contentPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));

	    setContentPane(contentPane);
	    contentPane.setLayout(null);

	    JLabel lblNewLabel = new JLabel("Welcome to the Equipment Enquiry System");
	    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 22));
	    lblNewLabel.setBounds(86, 23, 510, 100);
	    contentPane.add(lblNewLabel);

	    JLabel firstNameLabel = new JLabel("First Name: ");
	    firstNameLabel.setFont(new Font("Georgia", Font.BOLD, 17));
	    firstNameLabel.setBounds(38, 134, 117, 32);
	    contentPane.add(firstNameLabel);

	    JLabel lastNameLabel = new JLabel("Last Name: ");
	    lastNameLabel.setFont(new Font("Georgia", Font.BOLD, 17));
	    lastNameLabel.setBounds(363, 134, 129, 32);
	    contentPane.add(lastNameLabel);

	    firstNameTextField = new JTextField();
	    firstNameTextField.setBounds(154, 134, 156, 32);
	    contentPane.add(firstNameTextField);
	    firstNameTextField.setColumns(10);

	    lastNameTextField = new JTextField();
	    lastNameTextField.setBounds(474, 134, 156, 32);
	    contentPane.add(lastNameTextField);
	    lastNameTextField.setColumns(10);

	    JLabel lblNewLabel_3 = new JLabel("Please leave your message below");
	    lblNewLabel_3.setFont(new Font("Georgia", Font.BOLD, 17));
	    lblNewLabel_3.setBounds(38, 205, 376, 40);
	    contentPane.add(lblNewLabel_3);

	    JTextArea textArea = new JTextArea();
	    textArea.setBounds(38, 256, 413, 90);
	    contentPane.add(textArea);

	    JButton submit = new JButton("Submit");
	    submit.setMnemonic('S');
	    submit.setBackground(new Color(255, 255, 255));
	    submit.setFont(new Font("Georgia", Font.PLAIN, 15));
	    submit.setBounds(491, 286, 105, 32);
	    contentPane.add(submit);
	    
	    
	    JButton myMessagesButton = new JButton("Show Messages");
	    myMessagesButton.setFont(new Font("Georgia", Font.PLAIN, 15));
	  //Action displays message replies
	    myMessagesButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		 ClientTasks task=new ClientTasks();
	    		 int customerId = customer.getCustomerID(); // Implement this method
	    		 task.sendAction("Retrieve Messages");
	    		 task.sendCustomerId(customerId);
	    	   	task.receiveResponse();
	    	   	List<Message> replies=task.getReceivedMessages();
	    	   	
	    	   showMessages(replies); // Implement this method
	    	}
	    });
	    myMessagesButton.setBounds(491, 442, 139, 32);
	    contentPane.add(myMessagesButton);
	    
	    JLabel lblNewLabel_1 = new JLabel("My Messages");
	    lblNewLabel_1.setFont(new Font("Georgia", Font.BOLD, 17));
	    lblNewLabel_1.setBounds(38, 380, 117, 23);
	    contentPane.add(lblNewLabel_1);
	    
	    JScrollPane scrollPane = new JScrollPane();
	    scrollPane.setBounds(38, 419, 413, 114);
	    contentPane.add(scrollPane);
	    
	    myMessagesTextArea = new JTextArea();
	    scrollPane.setViewportView(myMessagesTextArea);

	    submit.addActionListener(new ActionListener() {
	      public void actionPerformed(ActionEvent e) {

	        String firstName = firstNameTextField.getText();
	        String lastName = lastNameTextField.getText();
	        String message = textArea.getText();
	        Message sentMessage = new Message(firstName, lastName, message);
	        //This method inserts message
	        ClientTasks task=new ClientTasks();
	        task.sendAction("Insert Message");
	        task.sendCustomer(customer); //Send customer object
	        System.out.println("Submit"+ customer);
	        task.sendMessage(sentMessage);
        	task.receiveResponse();
        	sendMessage(message);
	        
	        if (sentMessage == null) {
	          JOptionPane.showMessageDialog(null, "There was problem saving your message");
	          System.out.println("There was problem saving your message");

	        }

	      }
	    });
	  }
	    
	 //Method to display messages and replies
	  public void showMessages(List<Message> myMessages) {
		    StringBuilder message = new StringBuilder("Messages and Replies:\n");

		    for (Message msg : myMessages) {
		        message.append("Message ID: ").append(msg.getMessageID()).append("\n");
		        message.append("Message: ").append(msg.getMessage()).append("\n");
		        message.append("Reply: ").append(msg.getReply()).append("\n\n");
		    }

		    // Display the messages and replies in myMessagesTextArea
		    myMessagesTextArea.setText(message.toString());
		}
	    
	    public void sendMessage(String message) {
	        if (!message.isEmpty()) {
	            appendMessage("You: " + message);
	            myMessagesTextArea.setText("");
	        }
	    }

	    public void appendMessage(String message) {
	    	myMessagesTextArea.append(message + "\n");
	    	myMessagesTextArea.setCaretPosition(myMessagesTextArea.getDocument().getLength());
	    }
	}




