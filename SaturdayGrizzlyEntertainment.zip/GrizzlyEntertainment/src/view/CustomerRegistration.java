package view;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import controller.ClientTasks;
import model.Address;
import model.Customer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;

public class CustomerRegistration extends JFrame {

	private JPanel contentPane;
	private JTextField firstNameTextField;
	private JTextField lastNameTextField;
	private JTextField phoneTextField;
	private JLabel passwordLabel;
	private JTextField passwordTextField;
	private JLabel emailLabel;
	private JTextField emailTextField;
	private JLabel registrationLabel;
	private JLabel streetAddressLabel;
	private JTextField streetAddressTextField;
	private String[] parishList= {"Kingston", "St. Catherine", "Manchester", "Clarendon", "Portland", 
			"St. James", "St. Thomas", "Hanover", "Westmoreland", "Trelawney", "St.Ann", "St. Elizabeth", "Manchester", "St. Mary"};

	private ClientTasks task;
	//private static final Logger logger= LogManager.getLogger(CustomerRegistration.class);


	/**
	 * Create the frame.
	 */
	public CustomerRegistration(JFrame mainFrame) {
		
		//task = new ClientTasks();
		System.out.println("First time");
	        // Add a window listener to handle the window closing event
	        addWindowListener(new WindowAdapter() {
	            @Override
	            public void windowClosing(WindowEvent e) {
	                // Set the main frame (main window) to visible when the registration window is closed
	                mainFrame.setVisible(true);
	            }
	        });
		setTitle("Customer Registration");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 567, 550);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 221));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel firstNameLabel = new JLabel("First Name");
		firstNameLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		firstNameLabel.setBounds(26, 78, 84, 25);
		contentPane.add(firstNameLabel);
		
		firstNameTextField = new JTextField();
		firstNameTextField.setBounds(26, 114, 186, 25);
		contentPane.add(firstNameTextField);
		firstNameTextField.setColumns(10);
		
		JLabel lastNameLabel = new JLabel("Last Name");
		lastNameLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lastNameLabel.setBounds(26, 164, 95, 14);
		contentPane.add(lastNameLabel);
		
		lastNameTextField = new JTextField();
		lastNameTextField.setBounds(26, 196, 186, 25);
		contentPane.add(lastNameTextField);
		lastNameTextField.setColumns(10);
		
		JLabel phoneLabel = new JLabel("Phone");
		phoneLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		phoneLabel.setBounds(26, 336, 84, 14);
		contentPane.add(phoneLabel);
		
		phoneTextField = new JTextField();
		phoneTextField.setBounds(26, 361, 186, 25);
		contentPane.add(phoneTextField);
		phoneTextField.setColumns(10);
		
		passwordLabel = new JLabel("Password");
		passwordLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		passwordLabel.setBounds(26, 255, 84, 13);
		contentPane.add(passwordLabel);
		
		passwordTextField = new JTextField();
		passwordTextField.setBounds(26, 285, 186, 25);
		contentPane.add(passwordTextField);
		passwordTextField.setColumns(10);
		
		emailLabel = new JLabel("Email");
		emailLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		emailLabel.setBounds(330, 83, 49, 14);
		contentPane.add(emailLabel);
		
		emailTextField = new JTextField();
		emailTextField.setBounds(330, 114, 180, 25);
		contentPane.add(emailTextField);
		emailTextField.setColumns(10);
		
		registrationLabel = new JLabel("CUSTOMER REGISTRATION");
		registrationLabel.setForeground(new Color(1, 106, 112));
		registrationLabel.setBackground(new Color(1, 106, 112));
		registrationLabel.setFont(new Font("Broadway", Font.PLAIN, 16));
		registrationLabel.setBounds(164, 33, 227, 25);
		contentPane.add(registrationLabel);
		
		streetAddressLabel = new JLabel("Street Address");
		streetAddressLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		streetAddressLabel.setBounds(330, 164, 95, 14);
		contentPane.add(streetAddressLabel);
		
		streetAddressTextField = new JTextField();
		streetAddressTextField.setBounds(330, 196, 181, 25);
		contentPane.add(streetAddressTextField);
		streetAddressTextField.setColumns(10);
		
		JLabel parishLabel = new JLabel("Parish");
		parishLabel.setFont(new Font("Tahoma",  Font.PLAIN, 13));
		parishLabel.setBounds(330, 255, 49, 13);
		contentPane.add(parishLabel);
		
		JComboBox parishComboBox= new JComboBox<String>(parishList);
		parishComboBox.setSelectedItem("Kingston");
		
		parishComboBox.setBounds(330, 286, 180, 22);
		contentPane.add(parishComboBox);
		
		JButton registerButton = new JButton("Register");
		registerButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		registerButton.setBackground(new Color(210, 222, 50));
		
		//Testers
		firstNameTextField.setText("Jack");
		lastNameTextField.setText("Trucker");
		phoneTextField.setText("8888888888");
		passwordTextField.setText("1234");
		emailTextField.setText("Jack@gmail.com");
		streetAddressTextField.setText("23 Red Way");
		
		//Register Button Action Listener
		registerButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Get the values from the text fields
		    	int customerID=0;
		        String firstName = firstNameTextField.getText();
		        String lastName = lastNameTextField.getText();
		        String phone=phoneTextField.getText();
		        String password = passwordTextField.getText();
		        String email = emailTextField.getText();
		        Double accountBalance=0.0;
		        String streetAddress = streetAddressTextField.getText();
		        String parish= parishComboBox.getSelectedItem().toString();

		        // Validation checks
		        if (firstName.isEmpty() || !firstName.matches("^[a-zA-Z]+$")) {
		            // First name is empty or contains numbers
		            System.out.println("First name incorrect format");
		            // You can use JOptionPane.showMessageDialog or other methods to display messages.
		            JOptionPane.showMessageDialog(null, "No special characters are allowed in the input."+"\nField Cannot be Empty", "Validation Error", JOptionPane.ERROR_MESSAGE);
		            firstNameTextField.setBackground(new Color(233, 100, 121));
		        } else if (lastName.isEmpty() || !lastName.matches("^[a-zA-Z]+$")) {
		            // Last name is empty or contains numbers
		        	JOptionPane.showMessageDialog(null, "No special characters are allowed in the input."+"\nField Cannot be Empty", "Validation Error", JOptionPane.ERROR_MESSAGE);
		            lastNameTextField.setBackground(new Color(233, 100, 121));
		        } else if (phone.isEmpty() || !isPhoneNumberValid(phone)) {
		            // Username is empty or already exists
		        	JOptionPane.showMessageDialog(null, "Phone number is invalid or contains letters. Please enter digits only", "Validation Error", JOptionPane.ERROR_MESSAGE);
		            phoneTextField.setBackground(new Color(233, 100, 121));
		        } else if (password.isEmpty()) {
		        	JOptionPane.showMessageDialog(null, "No special characters are allowed in the input."+"\nField Cannot be Empty", "Validation Error", JOptionPane.ERROR_MESSAGE);
		            passwordTextField.setBackground(new Color(233, 100, 121));
		        } else if (email.isEmpty() || !email.contains("@")) {
		        	JOptionPane.showMessageDialog(null, "No special characters are allowed in the input."+"\nField Cannot be Empty", "Validation Error", JOptionPane.ERROR_MESSAGE);
		            emailTextField.setBackground(new Color(233, 100, 121));
		        } else if (streetAddress.isEmpty()) {
		        	JOptionPane.showMessageDialog(null, "Field Cannot be Empty", "Validation Error", JOptionPane.ERROR_MESSAGE);
		            streetAddressTextField.setBackground(new Color(233, 100, 121));
		        } else {
		        	//Add record to DB
		        	//Address address= new Address(streetAddress, parish);
		        	Customer customer= new Customer(customerID, firstName, lastName, password, email, phone, accountBalance, streetAddress, parish);
		        	
		        	System.out.println("Calling registerCustomer method");
		        	task = new ClientTasks();
		        	task.sendAction("Register Customer");
		        	task.sendCustomer(customer);
		        	task.receiveResponse();
		        }
		    }
		});
		
		registerButton.setBounds(364, 347, 107, 49);
		contentPane.add(registerButton);
	}
	
	// Function to check if the phone number contains only digits
	 private static boolean isPhoneNumberValid(String phoneNumber) {
	        // Check for both the format (digits only) and length (10 digits)
	        return phoneNumber.matches("^[0-9]{10}$");
	    }
	
	
}
