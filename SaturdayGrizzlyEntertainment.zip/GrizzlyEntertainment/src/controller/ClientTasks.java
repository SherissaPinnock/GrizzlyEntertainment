package controller;

import java.io.IOException;




import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.sql.Connection;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import model.Customer;
import model.Employee;
import model.Equipment;
import model.Message;
import model.Transaction;



//This class implements tasks from the customer side
public class ClientTasks {
	
	private Socket connectionSocket;
    private ObjectOutputStream objOs;
    private ObjectInputStream objIs;
    private String action = "";
    private boolean loginResult;
    private BlockingQueue<String> actionQueue; // Use a blocking queue to store actions
	private static final Logger logger= LogManager.getLogger(ClientTasks.class);
    private List<Transaction> receivedTransactions; //To store the received Transaction List from Server
    private List<Transaction> singleTransaction;
    private List<Equipment> receivedEquipment;
    private Customer receivedCustomer;
	private static final String URL="jdbc:mysql://localhost:3306/grizzlycustomers";
	private static final String USERNAME="root";
	private static final String PASSWORD="usbw";
		
	public ClientTasks() {
		 // Initialize the response queue
       // responseQueue = new ArrayBlockingQueue<>(100);
		this.createConnection();
    	this.configureStreams();
    	actionQueue = new LinkedBlockingQueue<>();
	}
		
		
	    //This method retrieves the employee details by id
	    public static Employee getEmployeeDetails(String employeeID) {
	        try {
	            Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	            String query = "SELECT * FROM employees WHERE employeeID = ?";
	            PreparedStatement preparedStatement = conn.prepareStatement(query);
	            preparedStatement.setString(1, employeeID);

	            ResultSet resultSet = preparedStatement.executeQuery();
	            if (resultSet.next()) {
	                // Retrieve employee details from the result set and create an Employee object
	                Employee employee = new Employee();
	                employee.setEmployeeID(resultSet.getInt("employeeID"));
	                employee.setFirstName(resultSet.getString("firstName"));
	                employee.setLastName(resultSet.getString("lastName"));
	                // Set other employee attributes as needed

	                return employee;
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return null; // Return null if no employee with the given ID was found
	    }

	    
	    //This method validates the employee credentials from the employee database
	    public static boolean validateEmployeeLogin(String id, String password) {
	        try {
	            Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	            String query = "SELECT * FROM employees WHERE employeeID = ? AND employeePassword = ?";
	            PreparedStatement preparedStatement = conn.prepareStatement(query);
	            preparedStatement.setString(1, id);
	            preparedStatement.setString(2, password);

	            ResultSet resultSet = preparedStatement.executeQuery();
	            return resultSet.next(); // If the result set has a row, the login is valid.
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
	     
	    
	    //This method retrieves the transaction info and adds it to a JComboBOx option list
	    public static void fillTransComboBox(int customerID, JComboBox<String> transComboBox) {
	        try {
	            Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
	            String sql = "SELECT rentalID FROM rentals WHERE customerID = ?";
	            PreparedStatement statement = conn.prepareStatement(sql);
	            statement.setInt(1, customerID);

	            ResultSet resultSet = statement.executeQuery();
	            
	            while (resultSet.next()) {
	                String rentalID = resultSet.getString("rentalID");
	                transComboBox.addItem(rentalID);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    
	    //Clients Side
	    
	    private void createConnection() {
	        try {
	        	//Create a socket to connect to the server
	        	connectionSocket = new Socket("127.0.0.1", 3308);
	        }
	        catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    private void configureStreams() {
	    	try {
	    		//Create an input stream to receive data from the server
	    		objIs = new ObjectInputStream(connectionSocket.getInputStream());
	    		//Create an output stream to send data to the server
	    		objOs = new ObjectOutputStream(connectionSocket.getOutputStream());
	    		
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    public void closeConnection() {
	    	try {
	    		objOs.close();
	    		objIs.close();
	    		connectionSocket.close();
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void sendAction(String action) {
	    	this.action = action;
	    	try {
	    		objOs.writeObject(action);
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void sendActionFromGUI(String action) {
	        // Add the action to the queue
	        actionQueue.offer(action);
	    }
	    
	    
	    public void sendCustomer(Customer cust) {
	    	try {
	    		objOs.writeObject(cust);
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void sendMessage(Message message) {
	    	try {
	    		objOs.writeObject(message);
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void sendCustomerId(int id) {
	    	try {
	    		objOs.writeObject(id);
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void sendCustomerPassword(String password) {
	    	try {
	    		objOs.writeObject(password);
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    public void sendDate(java.sql.Date date) {
	    	try {
	    		objOs.writeObject(date);
	    	} catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    //This method receives a customer result
	   public Customer receiveCustomer() {
		   Customer cust = new Customer();
			try {
				cust = (Customer) objIs.readObject();
				if (cust == null) {
					JOptionPane.showMessageDialog(null, "Record could not be found",
							"Find Record Status", JOptionPane.ERROR_MESSAGE);
				} else {
					System.out.println("Congratulations, Customer found.");
					return null;
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return cust;
			
	   }
	   
	   //This method receives responses from the server
	    @SuppressWarnings("unchecked")
		public void receiveResponse() {
	    	try {
	    		if(action.equalsIgnoreCase("Register Student")) {
	    			Boolean flag = (Boolean) objIs.readObject();
	    			if(flag == true) {
	    				JOptionPane.showMessageDialog(null, "Record added successfully",
	    						"Add Record Status", JOptionPane.INFORMATION_MESSAGE);
	    			}
	    		}
	    		if(action.equalsIgnoreCase("Customer Login")) {
	    			Boolean loginResult = (Boolean) objIs.readObject();
	    			if(loginResult == true) {
	    				setLoginResult(true);
	    				JOptionPane.showMessageDialog(null, "Welcome Valued Customer",
	    						"Logged in", JOptionPane.INFORMATION_MESSAGE);
	    			}else {
	    				setLoginResult(false);
	    			}
	    		}//endif
	    		if(action.equals("Get Customer Details")) {
	    				 System.out.println("Receiving customer");
	    				 //objOs.flush();
	    				 Customer customer = (Customer) objIs.readObject();
	    				 this.receivedCustomer=customer;
	    				 System.out.println(receivedCustomer);
	    				 logger.info(receivedCustomer);
	    			}//endif
	    		if(action.equals("View All Transactions")) {
	    			 List<Transaction> receivedTransactionList = (List<Transaction>) objIs.readObject(); // Receive the list
	    			System.out.println(receivedTransactionList);
	    			 this.receivedTransactions = receivedTransactionList;
	    			 
	    			 closeConnection();
	    		}
	    		if(action.equals("View Single Transaction")) {
	    			List<Transaction> singleTransactionList = (List<Transaction>) objIs.readObject(); // Receive the list
	    			logger.info("Single Transaction: "+ singleTransaction);
		    		this.singleTransaction = singleTransactionList;
	    		}
	    		if(action.equals("Insert Message")) {
	    			Boolean flag = (Boolean) objIs.readObject();
	    			if(flag == true) {
	    				JOptionPane.showMessageDialog(null, "Message added successfully",
	    						"Message Status", JOptionPane.INFORMATION_MESSAGE);
	    			}
	    		}
	    		if(action.equals("View Equipment")) {
	    			List<Equipment> receivedEquipmentList=(List<Equipment>) objIs.readObject();
	    			System.out.println("Received Equipment: "+ receivedEquipment);
	    			this.receivedEquipment=receivedEquipmentList;
	  
	    		}
	    		if(action.equals("Check Availability"))
	    		{
	    			
	    			 Object responseObject = objIs.readObject();
	    			 System.out.println("Received "+ responseObject);
	    			    if (responseObject instanceof Object[]) {
	    			        Object[] responseArray = (Object[]) responseObject;

	    			        if (responseArray.length >= 2) {
	    			            boolean flag = (boolean) responseArray[0];
	    			            double quotation = (double) responseArray[1];
	    			            System.out.print(quotation);
		
			    			if(flag==true)
			    			{
			    				JOptionPane.showMessageDialog(null, "Equipment is available bewteen selected dates. \nQuotation on Equipment =" + quotation, 
			    						"Availability Status", JOptionPane.INFORMATION_MESSAGE);
			    			}
			    			else
			    			{
			    				JOptionPane.showMessageDialog(null, "Sorry equipment is not available bewteen selected dates.", 
			    						"Availability Status", JOptionPane.INFORMATION_MESSAGE);
			    			}
			    		}
	    			    }
	    		}
	    		
	    		if(action.equals("Update")) {
	    			
	    		}
	    		if(action.equals("Delete Account")) {
	    			
	    		}
	    		 //end try	
	    	}catch (ClassCastException ex) {
	            ex.printStackTrace();
	        } catch (ClassNotFoundException ex) {
	            ex.printStackTrace();
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        } catch (Exception e) {
	        	e.printStackTrace();
	        }
	    }
	    
	   
	    public void startClient() {
	        // Create two threads for sending and receiving data
	        Thread sendThread = new Thread(() -> {
	            while (true) {
				    // Implement the logic for sending data to the server here
					String action = actionQueue.poll();
				    if (action != null) {
				        sendAction(action);
				    }
				    try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				   
				}
	        });

	        Thread receiveThread = new Thread(() -> {
	            try {
	                while (true) {
	                    // Implement the logic for receiving data from the server here
	                	receiveResponse();
	                	Thread.sleep(1000);
	                    
	                }
	            } catch ( InterruptedException e) {
	                e.printStackTrace();
	                // Handle exceptions if necessary
	            }
	        });

	        // Start both threads
	        sendThread.start();
	        receiveThread.start();
	    }

		public boolean getLoginResult() {
			return loginResult;
		}

		public void setLoginResult(boolean loginResult) {
			this.loginResult = loginResult;
		}
		
		public Customer getReceivedCustomer() {
			return receivedCustomer;
		}

		public void setReceivedCustomer(Customer receivedCustomer) {
			this.receivedCustomer = receivedCustomer;
		}

		// Create a getter for receivedTransactions
	    public List<Transaction> getReceivedTransactions() {
	        return receivedTransactions;
	    }

		public List<Transaction> getSingleTransaction() {
			return singleTransaction;
		}

		public void setSingleTransaction(List<Transaction> singleTransaction) {
			this.singleTransaction = singleTransaction;
		}


		public List<Equipment> getReceivedEquipment() {
			return receivedEquipment;
		}


		public void setReceivedEquipment(List<Equipment> receivedEquipment) {
			this.receivedEquipment = receivedEquipment;
		}
		
		/*if(action.equals("Check Availability")) {
		Boolean flag = (Boolean) objIs.readObject();
		//double quotation = (Double)objIs.readObject();
		if(flag == true) {
			JOptionPane.showMessageDialog(null, "Equipment is available between selected dates. \nQuotation",
					"Availability Status", JOptionPane.INFORMATION_MESSAGE);
		}
		else {
			JOptionPane.showMessageDialog(null, "Sorry Equipment is not available between selected dates.",
					"Availability Status", JOptionPane.INFORMATION_MESSAGE);
		}*/
}

		

		
	   
	  
	








