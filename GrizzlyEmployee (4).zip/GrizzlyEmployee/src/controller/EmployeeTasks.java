package controller;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Date;
import java.util.List;

import javax.swing.JOptionPane;

import model.Employee;
import model.Message;
import model.Transaction;

public class EmployeeTasks {
	private Socket connectionSocket;
    private ObjectOutputStream objOs;
    private ObjectInputStream objIs;
    private String action = "";
    private List<Message> retrievedMessagesList;
    private boolean loginResult;
    
    public EmployeeTasks() {
    	this.createConnection();
    	this.configureStreams();
    }
    
    private void createConnection() {
        try {
        	//Create a socket to connect to the server
        	connectionSocket = new Socket("127.0.0.1", 3308);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void configureStreams() {
    	try {
    		//Create an input stream to receive data from the server
    		objIs = new ObjectInputStream(connectionSocket.getInputStream());
    		//Create an output stream to send data to the server
    		objOs = new ObjectOutputStream(connectionSocket.getOutputStream());
    		
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void closeConnection() {
    	try {
    		objOs.close();
    		objIs.close();
    		connectionSocket.close();
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendAction(String action) {
    	this.action = action;
    	try {
    		objOs.writeObject(action);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendMessage(Message message) {
    	try {
    		objOs.writeObject(message);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendInt(int id) {
    	try {
    		objOs.writeObject(id);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendDate(Date selectedStartDate) {
    	try {
    		objOs.writeObject(selectedStartDate);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendString(String string) {
    	try {
    		objOs.writeObject(string);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void sendEmployee(Employee emp) {
    	try {
    		objOs.writeObject(emp);
    	} catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    @SuppressWarnings("unchecked")
	public void receiveResponse(){
    	try {
    		if(action.equals("Employee Login")) {
    			Boolean loginResult = (Boolean) objIs.readObject();
    			if(loginResult == true) {
    				setLoginResult(true);
    				JOptionPane.showMessageDialog(null, "Welcome Back Employee",
    						"Logged in", JOptionPane.INFORMATION_MESSAGE);
    			}else {
    				setLoginResult(false);
    			}
    		}
    		if(action.equalsIgnoreCase("Schedule Equipment")) {
    			Boolean flag = (Boolean) objIs.readObject();
    			if(flag == true) {
    				JOptionPane.showMessageDialog(null, "Equipment scheduled successfully",
    						"Add Record Status", JOptionPane.INFORMATION_MESSAGE);
    			}
    		if(action.equals("Get Customer Messages")) {
    			List<Message> receivedMessages = (List<Message>) objIs.readObject(); // Receive the list
    			this.retrievedMessagesList = receivedMessages;
    			System.out.println("Received:"+receivedMessages);
    		}
    	}
    	}catch (ClassCastException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
        	e.printStackTrace();
        }  
    
    }
    
    public boolean getLoginResult() {
		return loginResult;
	}

	public void setLoginResult(boolean loginResult) {
		this.loginResult = loginResult;
	}

	public Employee getReceivedEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Message> getRetrievedMessagesList() {
		return retrievedMessagesList;
	}

	public void setRetrievedMessagesList(List<Message> retrievedMessagesList) {
		this.retrievedMessagesList = retrievedMessagesList;
	}
}
