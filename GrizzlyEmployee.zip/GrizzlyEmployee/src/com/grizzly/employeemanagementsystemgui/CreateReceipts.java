package com.grizzly.employeemanagementsystemgui;

import javax.swing.*;

import controller.EmployeeTasks;

import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class CreateReceipts {
	
	private static JTextField customerIDField;
	private static JFrame frame;
	private static JTextArea receiptArea;
	private static List<String> receiptMessages;
	private static int currentReceiptIndex;
   

    public static void showReceiptsGUI() {
        frame = new JFrame("Generate Receipts");
        frame.setSize(400, 300);

     // Create a label and text field for entering Customer ID
        JLabel customerIDLabel = new JLabel("Customer ID:");
        customerIDField = new JTextField(20); 

     // Create a button to generate receipts
        JButton generateButton = new JButton("Generate Receipt");
        generateButton.addActionListener(e -> generateReceipts());
        
    


     // Create a panel to hold the components
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panel.add(customerIDLabel);
        panel.add(customerIDField);
        panel.add(generateButton);

        // Add the panel to the frame
        frame.add(panel);
        
     // Set the heading "GrizzlyEntertainment"
        JLabel headingLabel = new JLabel("Grizzly Entertainment", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 16));
        frame.add(headingLabel, BorderLayout.NORTH);

        // Set frame properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        
        // Create a text area for displaying receipts
        receiptArea = new JTextArea(10, 30);
        receiptArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(receiptArea);

        // Create a button to navigate through receipts
        JButton nextButton = new JButton("Next");
        nextButton.addActionListener(e -> displayNextReceipt());

        // Add components to the panel
        panel.add(scrollPane);
        panel.add(nextButton);
    }

    private static void generateReceipts() {

            // Get Customer ID from the text field
            int customerID = Integer.parseInt(customerIDField.getText());
            EmployeeTasks empTask=new EmployeeTasks();
            empTask.sendAction("Get Receipts");
            empTask.sendInt(customerID);
            empTask.receiveResponse();
            receiptMessages=empTask.getReceiptList();
            
            currentReceiptIndex = 0; // Reset to the first receipt
            displayReceiptPopup();
            displayReceiptPopup(receiptMessages);

            
    }

    

    private static void displayReceiptPopup(List<String> receiptMessage){
        
    	
        // Show receipt in a pop-up
        JOptionPane.showMessageDialog(null, receiptMessage, "Receipt", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void displayReceiptPopup() {
        if (receiptMessages != null && !receiptMessages.isEmpty()) {
            receiptArea.setText(receiptMessages.get(currentReceiptIndex));
        } else {
            receiptArea.setText("No receipts found for this customer.");
        }
    }

    private static void displayNextReceipt() {
        if (receiptMessages != null && !receiptMessages.isEmpty()) {
            currentReceiptIndex++;
            if (currentReceiptIndex >= receiptMessages.size()) {
                currentReceiptIndex = 0; // Start from the first receipt if reached the end
            }
            receiptArea.setText(receiptMessages.get(currentReceiptIndex));
        }
    }



    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                CreateReceipts.showReceiptsGUI();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
