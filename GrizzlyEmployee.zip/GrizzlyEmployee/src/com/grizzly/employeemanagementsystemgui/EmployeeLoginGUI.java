package com.grizzly.employeemanagementsystemgui;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;


import controller.EmployeeTasks;

import model.Employee;


import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class EmployeeLoginGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	EmployeeTasks empTask;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmployeeLoginGUI frame = new EmployeeLoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EmployeeLoginGUI() {
		setTitle("Employee Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 507, 329);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(210, 222, 50));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel titleLabel = new JLabel("GRIZZLY ENTERTAINMENT");
		titleLabel.setFont(new Font("Broadway", Font.PLAIN, 14));
		titleLabel.setBounds(23, 112, 215, 26);
		contentPane.add(titleLabel);
		
		JLabel titleLabel_1 = new JLabel("Equipment Rental");
		titleLabel_1.setFont(new Font("Broadway", Font.PLAIN, 12));
		titleLabel_1.setBounds(56, 143, 140, 14);
		contentPane.add(titleLabel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 210));
		panel.setBounds(260, 0, 233, 292);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel loginLabel = new JLabel("EMPLOYEE LOGIN");
		loginLabel.setBounds(41, 29, 155, 17);
		panel.add(loginLabel);
		loginLabel.setFont(new Font("Georgia", Font.BOLD, 15));
		
		JLabel empPasswordLabel = new JLabel("Employee Password");
		empPasswordLabel.setBounds(41, 154, 133, 14);
		panel.add(empPasswordLabel);
		empPasswordLabel.setFont(new Font("Georgia", Font.PLAIN, 13));
		
		JLabel empIDLabel = new JLabel("Employee ID");
		empIDLabel.setBounds(41, 75, 84, 14);
		panel.add(empIDLabel);
		empIDLabel.setFont(new Font("Georgia", Font.PLAIN, 13));
		
		textField = new JTextField();
		textField.setBounds(41, 100, 96, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(41, 184, 96, 20);
		panel.add(passwordField);
		
		JButton loginButton = new JButton("LOGIN");
		loginButton.setBounds(41, 232, 89, 23);
		panel.add(loginButton);
		loginButton.setForeground(new Color(255, 255, 255));
		loginButton.setBackground(new Color(1, 106, 112));
		loginButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String id = textField.getText();
			     String password = new String(passwordField.getPassword());
				empTask= new EmployeeTasks();
	        	
	        	//Create a blank customer object that can hold the id and password. 
	        	Employee employee = new Employee();
	        	int intID= Integer.valueOf(id);
	        	employee.setEmployeeID(intID);
	        	employee.setEmployeePassword(password);
	        	
	        	empTask.sendAction("Employee Login");
	        	empTask.sendEmployee(employee); // Send the customer object

	        	empTask.receiveResponse();
	        	boolean loginResult = empTask.getLoginResult();
	        	System.out.println(loginResult);
	        	
	        	if (loginResult) {
	                //If Login is successful, open the Employee Dashboard
	            	//Send Action to Server
	            	empTask= new EmployeeTasks();
	            	empTask.sendAction("Get Employee Details");
	            	System.out.println("Sending action");
	            	
	            	//Send id to server
	            	empTask.sendInt(employee.getEmployeeID());
	            	System.out.println("Sent "+ employee.getEmployeeID());
	            	 // Receive and store the customer details from the server
	            	empTask.receiveResponse(); //Corrected
	            	Employee receivedEmployee = empTask.getReceivedEmployee();
	            	System.out.println(receivedEmployee);
	            	
	            	
	                System.out.println("Customer Login successful! Opening customer dashboard...");
	                EmployeeManagementSystemGUI empDashboard;
					try {
						empDashboard = new EmployeeManagementSystemGUI();
						 empDashboard.setVisible(true);
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	               
	                setVisible(false);
	            } else {
	                // Display an error message if the login fails.
	                JOptionPane.showMessageDialog(null, "Customer Login failed. Invalid ID or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
	                System.out.println("Customer Login failed. Invalid ID or password.");
	                
	            }
			}
		});
	}
}
