package model;

import java.io.Serializable;

public class Address implements Serializable{
	private String streetName;
	private String parish;
	
	public Address(String streetName, String parish) {
		this.streetName=streetName;
		this.parish=parish;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getParish() {
		return parish;
	}
	public void setParish(String parish) {
		this.parish = parish;
	}
}
