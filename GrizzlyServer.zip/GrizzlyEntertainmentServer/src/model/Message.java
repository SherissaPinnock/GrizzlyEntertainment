package model;

import java.io.Serializable;

public class Message implements Serializable{

	  private int messageID;
	  private int customerID;
	  private String firstName;
	  private String lastName;
	  private String message;
	  private String reply;

	  

	public Message() {
	    messageID = 0;
	    firstName = "";
	    lastName = "";
	    message = "";
	  }

	  // used to insert new messages in the database so that the auto increment is
	  // able to work
	  public Message(String firstName, String lastName, String message, String reply) {
	    this.firstName = firstName;
	    this.lastName = lastName;
	    this.message = message;
	    this.reply=reply;
	  }

	  // used for retrieving messages from the database
	  public Message(String firstName, String lastName, String message) {
	    this.firstName = firstName;
	    this.lastName = lastName;
	    this.message = message;
	  }

	  public Message(int messageID, String messageContent, String replyContent) {
		// TODO Auto-generated constructor stub
		  this.messageID = messageID;
		  this.message = messageContent;
		  this.reply=replyContent;
	}
	  
	  
	public Message(int messageID, int customerID, String firstName, String lastName, String message, String reply) {
		this.messageID = messageID;
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.message = message;
		this.reply = reply;
	}

	public int getMessageID() {
	    return messageID;
	  }

	  public void setMessageID(int messageID) {
	    this.messageID = messageID;
	  }

	  public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getFirstName() {
	    return firstName;
	  }

	  public void setFirstName(String firstName) {
	    this.firstName = firstName;
	  }

	  public String getMessage() {
	    return message;
	  }

	  public String getLastName() {
	    return lastName;
	  }

	  public void setLastName(String lastName) {
	    this.lastName = lastName;
	  }

	  public void setMessage(String message) {
	    this.message = message;
	  }
	  
	  public String getReply() {
			return reply;
		}

	  public void setReply(String reply) {
			this.reply = reply;
		}

	@Override
	public String toString() {
		return "Message [messageID=" + messageID + ", firstName=" + firstName + ", lastName=" + lastName + ", message="
				+ message + ", reply=" + reply + "]";
	}

	

	}

