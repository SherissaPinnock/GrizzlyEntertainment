package model;

import java.io.Serializable;

public class Message implements Serializable{

	  private int messageID;
	  private String firstName;
	  private String lastName;
	  private String message;

	  public Message() {
	    messageID = 0;
	    firstName = "";
	    lastName = "";
	    message = "";
	  }

	  // used to insert new messages in the database so that the auto increment is
	  // able to work
	  public Message(String firstName, String lastName, String message) {
	    this.firstName = firstName;
	    this.lastName = lastName;
	    this.message = message;
	  }

	  // used for retrieving messages from the database
	  public Message(int messageID, String firstName, String lastName, String message) {
	    this.messageID = messageID;
	    this.firstName = firstName;
	    this.lastName = lastName;
	    this.message = message;
	  }

	  public int getMessageID() {
	    return messageID;
	  }

	  public void setMessageID(int messageID) {
	    this.messageID = messageID;
	  }

	  public String getFirstName() {
	    return firstName;
	  }

	  public void setFirstName(String firstName) {
	    this.firstName = firstName;
	  }

	  public String getMessage() {
	    return message;
	  }

	  public String getLastName() {
	    return lastName;
	  }

	  public void setLastName(String lastName) {
	    this.lastName = lastName;
	  }

	  public void setMessage(String message) {
	    this.message = message;
	  }

	  public String toString() {
	    return "Message [message ID=" + messageID + "firstName=" + firstName + ", lastName=" + lastName + ", message="
	        + message + "]";
	  }

	}

