package model;

import javax.persistence.Table;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
@Table(name="equipment")
public class Equipment implements Serializable{
	
	@Id
	@Column(name="equipmentID")
	private int equipmentID;
	@Column(name="equipmentName")
	private String equipmentName;
	@Column(name="equipmentCategory")
	private String equipmentCategory;
	
	@Column(name="equipmentCostPerDay")
	private double equipmentCostPerDay;
	@Column(name="equipmentDescription")
	private String equipmentDescription;
	@Column(name="availabilityStatus")
	private String availabilityStatus;
	
	
	
	public Equipment(int equipmentID, String equipmentName, String equipmentCategory, double equipmentCostPerDay,
			String equipmentDescription) {
		this.equipmentID = equipmentID;
		this.equipmentName = equipmentName;
		this.equipmentCategory = equipmentCategory;
		this.equipmentCostPerDay = equipmentCostPerDay;
		this.equipmentDescription = equipmentDescription;
	}
	
	public Equipment() {
		this.equipmentID = 0;
		this.equipmentName = "";
		this.equipmentCategory = "";
		this.equipmentCostPerDay = 0.0;
		this.equipmentDescription = "";
	}
	
	public int getEquipmentID() {
		return equipmentID;
	}
	public void setEquipmentID(int equipmentID) {
		this.equipmentID = equipmentID;
	}
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public String getEquipmentCategory() {
		return equipmentCategory;
	}
	public void setEquipmentCategory(String equipmentCategory) {
		this.equipmentCategory = equipmentCategory;
	}
	public double getEquipmentCostPerDay() {
		return equipmentCostPerDay;
	}
	public void setEquipmentCost(double equipmentCost) {
		this.equipmentCostPerDay = equipmentCost;
	}
	public String getEquipmentDescription() {
		return equipmentDescription;
	}
	public void setEquipmentDescription(String equipmentDescription) {
		this.equipmentDescription = equipmentDescription;
	}
	

	public void setEquipmentCostPerDay(double equipmentCostPerDay) {
		this.equipmentCostPerDay = equipmentCostPerDay;
	}

	public String getAvailabilityStatus() {
		return availabilityStatus;
	}

	public void setAvailiablityStatus(String equipmentStatus) {
		this.availabilityStatus = availabilityStatus;
	}

	@Override
	public String toString() {
		return "Equipment [equipmentID=" + equipmentID + ", equipmentName=" + equipmentName + ", equipmentCategory="
				+ equipmentCategory + ", equipmentCost=" + equipmentCostPerDay + ", equipmentDescription="
				+ equipmentDescription + "]";
	}
	
	
}
